# NAVEX Data Analytics Documentation <img src="assets/navex_icon.png" align="right" height="120" />

![Actively Maintained](https://img.shields.io/badge/Maintenance%20Level-Actively%20Maintained-green.svg)

This repository is used to store documentation for the NAVEX Data Analytics team; serving to outline the key metrics and deliverables used within the Customer Success Organization.

## Metrics

For each department, metric documentation is stored in it's own Markdown file. If a metric does not fit into any one department, it is stored in **General**.

- [General](docs/General%20Metrics.md)
- [Customer Support](docs/Support%20Metrics.md)
- [Implementation](docs/Implementation%20Metrics.md)
- [Professional Services](docs/Professional%20Services%20Metrics.md)
- [Technical Specialist](docs/Technical%20Specialist%20Metrics.md)
- [Telecom](docs/Telecom%20Metrics.md)
- [Web Services](docs/Web%20Services%20Metrics.md)

## Key Deliverables

### The Pursuit

The Pursuit is a referral contest that we provide monthly recurring reporting on. 

**Process Notes:** [The Pursuit](docs/The%Pursuit%Metrics.md)

### iLevel

The Customer Success Organization ilevel is a monthly deliverable that summarizes departmental metrics from across CSO in a tabular format. This allows management to track team performance over time while providing oversight to executive leadership. The majority of data is compiled by the Data Analytics team, with some metrics being provided by Finance.

**Process Notes:** [iLevel](docs/iLevel.md)

### Migration Documentation

The migrations of PolicyTech, AlertLine/IntegriLink, Expolink, and Telephony are documented by the CSO Data Analysts. Documentation also is used in the iLevel.

**Process Notes:** [Migration Documentation](docs/Migration%20Documentation.md)

### Board Deck

The Customer Success Organization Board Deck is a quarterly deliverable that visualizes key CSO metrics and presents them to executive leadership. Data is compiled by the Data Analytics team with commentary by senior managers and directors.

**Process Notes:** [Board Deck](docs/Board%20Deck.md)

### Target Date Analysis

Target Date Analysis is designed to track the accuracy of Target Date predictions on Delivery Services Milestones. Reporting is compiled on a monthly basis for Implementation and Professional Services leadership.

**Process Notes:** [Target Date Analysis](docs/Target%20Date%20Analysis.md)

### Migration Financial Workbooks

For each migration currently in progress, a workbook analyzing Asset history is compiled monthly. This is then set to Finance for review and publication.

**Location:** [SharePoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx?viewid=589ddb82%2D9e47%2D4f78%2Db574%2Dea604178eb7c&id=%2Fsites%2FDataAnalystTeam%2FShared%20Documents%2FMigration%20Workbooks)

## Process Notes

These process notes contain instructions for common Data Analytics tasks that do not fall under a specific key deliverable.

- [Utilization Calculations](docs/Utilization%20Calculations.md)
- [Data preparation for Benchmark Shiny Dashboard](docs/Crosswalk%20and%20cleaner%20for%20Benchmark%20Data.md)

## Onboarding

The following document contains resources for people moving into the Data Analytics team within NAVEX. Along with useful links and required software, it also provides resources for independent training that can be completed between more structured sessions.

- [Onboarding](docs/Onboarding.md)
