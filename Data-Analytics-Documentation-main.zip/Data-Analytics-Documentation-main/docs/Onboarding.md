# Onboarding

Starting in a new role is always challenging, whether joining a company for the first time or moving teams internally. This document is designed for people moving into a Data Analytics role within NAVEX Global and aims to provide useful resources during the early stages of onboarding. Any questions regarding the content of this document, or the onboarding process, can be directed to the `#cso_analytics_team_chat` Slack channel or your manager.

This document will be updated over time to ensure content is relevant to people joining the Data Analytics team. Pull Requests with additions and amendments are welcomed, as are Issues with suggestions or recommendations.

- [Links](#Links)
- [Software](#Software)
- [Work Assignment](#Work-Assignment)
- [Project Guidelines](#Project-Guidelines)
- [Salesforce Trailheads](#Salesforce-Trailheads)
- [Exercises](#Exercises)
- [Additional Resources](#Additional-Resources)

## Access

Data Analytics team members will need access to the following systems to access Product-specific data necessary for the role

- [NAVEXOne US](https://navexadmin.navexone.com/): Platforminator US
- [NAVEXOne EU](https://navexadmin.navexone.eu/): Platforminator EU
- [EthicsPoint US](https://secure.ethicspoint.com/Domain/Admin/Login/Index): EP Admin US
- [EthicsPoint EU](https://secure.ethicspoint.eu/Domain/Admin/Login/Index): EP Admin EU
- [PolicyTech US](https://maint.policytech.com/ptadmin/#/accounts): PT Admin US
- [PolicyTech EU](https://maint.policytech.eu/ptadmin/#/accounts): PT Admin EU
- [Pendo](https://app.pendo.io/login): Pendo
- [BI Snowflake](https://app.snowflake.com/navex/businesssystems/): Snowflake (Business Systems)
- [MFT](https://mft.navex.com:4432/?Command=Login): CSO MFT SFTP Server

## Links

The majority of NAVEX resources are available as Web Applications. It is recommended that the following links are bookmarked as they will be used on a regular basis.

- [OneDrive](https://navex-my.sharepoint.com/): Personal cloud storage and collaborative documents.

- [SharePoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx): Cloud storage for Data Analytics team documents.

- [Salesforce](https://navex.lightning.force.com/lightning/page/home): Customer Relationship Management system.

- [Data Analytics Team Dashboard](https://navex.lightning.force.com/lightning/r/Dashboard/01Z1T000001KJsmUAG/view): Salesforce dashboard for managing Data Analytics cases and workload.

- [GitHub](https://github.com/NAVEX-Analytics): Version control and cloud storage for code and documentation.

- [Data Analytics Documentation](https://github.com/NAVEX-Analytics/Data-Analytics-Documentation): A GitHub repository containing documentation for the Data Analytics function.

- [Confluence](https://confluence.navexglobal.com/): Company intranet for employee resources.

- [KACE](https://kace.navexglobal.com/): IT help desk for support tickets.

- `S:\Services\Data Services\Reporting`: File server for storing Data Analytics documents. A VPN connection is required if not connected to a NAVEX network.

## Software

Laptops issued by NAVEX are preinstalled with generic software such as Microsoft Office. Additional software is often required within the Data Analytics function and should be installed as part of the onboarding process. In the event that an Administrator needs to authorize an instillation, an IT Support Ticket will need to be raised via the [KACE](https://kace.navexglobal.com/) system. It is recommended to copy your manager into software request tickets for visibility.

Below is a list of key software packages to install, along with links to their download pages and instillation instructions.

- [Slack](https://slack.com/intl/en-gb/downloads/windows): Used for instant messaging and team communications.

- [PowerBI Desktop](https://powerbi.microsoft.com/en-us/desktop/): Widely used dashboarding tool across the company. Connects to Salesforce & Snowflake data by the 'PowerBI Semantic Model'

- [Visual Studio Code](https://code.visualstudio.com/download): General text editor. Other free editors such as Atom can be used if preferred.

- [R](https://cran.r-project.org/mirrors.html): Programming language for statistical analysis.

- [RStudio Desktop](https://rstudio.com/products/rstudio/download/): Integrated Development Environment for R.

- [Python](https://www.python.org/downloads/): General purpose programming language used for statistical analysis.
  - On Windows computers, ensure the `Add Python 3.x to PATH` option is checked in the installer. If this is not done, any Python Command Line scripts, such as `pip install`, will need to be preceded by `py -m`.

- [Git](https://git-scm.com/download/win): System and Command Line functionality for Git version control.

- [GitHub Desktop](https://desktop.github.com/): Graphical interface for local Git repositories and GitHub functionality.

- [GitHub CLI](https://cli.github.com/) (*Optional*): Command Line Interface for GitHub commands and functionality. Only required if planning to manage GitHub repositories from the command line.

- Jupyter Notebook: Interactive notebook for Python and R.
  1. Install `Python` and `R`
  2. In the Windows Command Prompt run: `pip install jupyter`
  3. In the R Console run: `install.packages('IRkernel')`
  4. In the R Console run: `IRkernel::installspec(user = FALSE)`
  5. To run Jupyter Notebook, type `jupyter notebook` in the Windows Command Prompt.
  6. Instructions for creating a Desktop shortcut to launch Jupyter Notebook are available in [Additional Resources](#Jupyter-Notebook).

## Work Assignment

The Data Analytics team works primarily within the Customer Success Organization of NAVEX. It's key function is to support the organization with the production and maintenance of data reporting, and to manage requests regarding data usage and integrity. Due to this it is common to work with teams across the business to ensure accuracy and accessability.

Work within the Data Analytics team can be broken into the following categories:

- **Key Deliverables** - These represent high-priority reporting that is produced on a set cadence. Each deliverable is typically owned by one member of the Data Analytics team with other members contributing subject specific information when necessary. Examples include the Board Deck and iLevel.

- **Change Requests and Amendments** - These represent maintenance updates and small additions to existing reporting. They are typically quick to complete and are picked up by, or assigned to, a Data Analyst with bandwidth at the time the request is received.

- **Projects** - These encompasses requests that require a longer time period to complete and often involve scoping and frequent stakeholder interaction. These are assigned based on current and long-term bandwidth as well as subject specific knowledge.

The majority of Data Analytics requests are submitted as a Case in Salesforce. Cases can be raised manually using the `CSO Ops` Case Record Type and the `Reporting & Analytics` CSO Type. However, it is encouraged for requests to be made by emailing <CSOData@navexglobal.com>. This automatically creates a case within Salesforce and notifies the Data Analytics team to it's presence.

Once a Salesforce Case as been created, we aim to assign the request to a Data Analyst and provide an acknowledgement within **24** hours. If a conversation regarding case assignment is required, this should take place in the `#cso_analytics_team_chat` Slack channel. An overview of current cases can be seen on the [Data Analytics Team Dashboard](https://navex.lightning.force.com/lightning/r/Dashboard/01Z1T000001KJsmUAG/view), which should be monitored throughout the day.

When working on a case, the following fields should be updated:

- **Case Owner**: This should be the primary Data Analyst working on the case. If assigning to someone other than yourself, ensure the `Send notification email` option is checked.

- **Project Contact**: This should be set to the Salesforce user that requested the work. For internal time tracking cases, this should be set to the `Case Owner`.

- **Due Date**: If a due date is not specified in the request, it should the set in line with the complexity of the required work and communicated to the **Project Contact**.

- **Status**: This denotes the current status of the case and should be updated as work is carried out.

| Status      | Description                                                              |
|:------------|:-------------------------------------------------------------------------|
| New         | A new case                                                               |
| In Progress | Work on the case is underway                                             |
| On Hold     | Work is awaiting further authorization to continue                       |
| Complete    | Work has been completed and is awaiting review by **Project Contact**    |
| Closed      | Work has been completed, reviewed, and signed off by **Project Contact** |

## Project Guidelines

Data Analytics projects come in many forms and are often best completed using different tools and techniques. When deciding how to approach a new project or analysis, the following criteria should be taken into consideration to ensure the quality of the final deliverable. If experimenting with new tools, greater emphasis should be put on each of these.

- **Accessible** - Ensure the final deliverable is accessible to all stakeholders, and supporting files accessible by members of the Data Analytics team. This can usually be achieved via the use of Salesforce Reporting, SharePoint, and GitHub.

- **Auditable** - Ensure another member of the Data Analytics team can easily review the project, understanding the purpose and intended results.

- **Documented** - Ensure the project is documented in a manner that explains what has been done and why. This can be done in the document itself or as separate process notes.

- **Maintainable** - Ensure the project can be maintained and updated to accommodate reasonable requests, by another member of the Data Analytics team if necessary.

- **Repeatable** - Ensure any analysis can be repeated by another member of the Data Analytics team with the same output being achieved.

- **Scalable** - Ensure the project can be scaled to accommodate larger data sets if necessary.

## Salesforce Trailheads

Salesforce is used throughout NAVEX to manage customer interaction and resource activity. In order to provide help to new users, Salesforce provides free training in the form of [Trailhead](https://trailhead.salesforce.com/). Trailhead is a platform designed for interactive learning of Salesforce features and functionality; covering a range of business roles and use cases. Below is a list of modules relevant to a Data Analytics role within NAVEX which serve as worthwhile training between structured sessions. As Trailhead receives constant updates, it is encouraged  to investigate other modules and add them to this list if useful.

- [Trailhead Basics](https://trailhead.salesforce.com/content/learn/modules/trailhead_basics)

- [Salesforce User Basics](https://trailhead.salesforce.com/content/learn/modules/lex_salesforce_basics)

- [Salesforce Platform Basics](https://trailhead.salesforce.com/content/learn/modules/starting_force_com)

- [CRM for Lightning Experience](https://trailhead.salesforce.com/content/learn/modules/lex_implementation_basics)

- [Reports and Dashboards for Lightning Experience](https://trailhead.salesforce.com/content/learn/modules/lex_implementation_reports_dashboards)

- [Quick Start: Reports and Dashboards](https://trailhead.salesforce.com/en/content/learn/projects/quickstart-reports)

- [Creating Reports and Dashboards for Sales and Marketing Managers](https://trailhead.salesforce.com/content/learn/projects/create-reports-and-dashboards-for-sales-and-marketing-managers)

- [Data Quality](https://trailhead.salesforce.com/content/learn/modules/data_quality)

- [Filter Report Data](https://trailhead.salesforce.com/en/content/learn/projects/rd-filter-report-data)

- [Evaluate Report Data with Formulas](https://trailhead.salesforce.com/en/content/learn/projects/rd-summary-formulas)

- [Database & .NET Basics](https://trailhead.salesforce.com/en/content/learn/modules/database_basics_dotnet)

## Exercises

The following exercises can be undertaken during onboarding. They are designed to emulate real reporting requests and will allow you to familiarize yourself with NAVEX data and reporting tools. It is encouraged for any questions to be directed to the `#cso_analytics_team_chat` Slack channel where help will be provided.

- **Documentation Review** - Review and familiarize yourself with the documentation in the [Data-Analytics-Documentation](https://github.com/NAVEX-Analytics/Data-Analytics-Documentation) GitHub repository. Try recreating some of the metrics as Salesforce reports and create a dashboard to display them.

- **Documentation Update** - Clone this repository and create a pull request containing an amendment to this document. This could be a new section, an update to an existing one, or the addition of useful resources.

- **EthicsPoint ARR** - In Salesforce, create a report that shows the current USD ARR value of all active EthicsPoint Assets. Hint: *Asset: Product Family* and *Asset: Asset Status*.

- **Support Cases** - In Salesforce, create a report that shows the number of Support Cases opened per month in the current year. Hint: *Case: Case Record Type*.

- **Team Dashboard** - In Salesforce, create a new Data Analytics team dashboard showing all `Reporting & Analytics` cases. Multiple reports will be required, but try to use as few as possible.

- **Power Query Workbook** - In Excel Power Query, create a workbook that connects to Salesforce and loads all **Issues** created in the current year. Calculate the number of Issues per Type (Issue_Type__c), Product (Product_Family__c), and Department (Department_of_Issue__c) and visualize them in a manner suitable for a executive presentation. All data and visualizations should update when the workbook is refreshed.

- **R Script** - Create an R script that pulls the current year's Net Promoter Score data from Salesforce using the `install.packages("salesforcer")` package and an `SOQL Query`. Create a graph showing the average NPS score per month. The [Data-Analytics-Documentation](https://github.com/NAVEX-Analytics/Data-Analytics-Documentation) and [Customer-Success-iLevel](https://github.com/NAVEX-Analytics/Customer-Success-iLevel) GitHub repositories contain all the code and information needed to obtain the data.

- **Jupyter Notebook** - Use a Jupyter Notebook to answer the following question: **Is there a linear relationship between an Account's `Total Asset ARR` and the number of Support Cases they raise per year?** This can be done in either Python or R, but it is recommended to do this in R in order to utilize the `salesforcer` package. Examples of similar projects can be found in the [Project-Notebook](https://github.com/NAVEX-Analytics/Project-Notebooks) GitHub repository.

## NAVEX Product Training Resources

Product introductions begin day 4, product walk-throughs begin week 2. [Bootcamp Links](https://confluence.navexglobal.com/display/CSO2/CSO+MAY+2021+Boot+Camp)

- NAVEX One: [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/DAY%204%20NAVEX%20One.mp4?version=1&modificationDate=1621382070037&api=v2)

- EthicsPoint: [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/DAY%204%20EPIM.mp4?version=1&modificationDate=1621382131333&api=v2), [Slide Deck](https://confluence.navexglobal.com/download/attachments/170797518/MOST%20REVISED%20EthicsPoint%20Bootcamp%20Deep%20Dive.pptx?version=1&modificationDate=1621279282227&api=v2)

- PolicyTech: [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/CSO%20Bootcamp%20-%20Day%205-PT.mp4?version=1&modificationDate=1621021234730&api=v2), [Slide Deck](https://confluence.navexglobal.com/download/attachments/170797518/Bootcamp%20Deep%20Dive%20Decks.PolicyTech.NM.pptx?version=1&modificationDate=1621449969273&api=v2)

- NAVEXEngage: [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/DAY%204%20NE.mp4?version=1&modificationDate=1621382106837&api=v2), [Slide Deck](https://confluence.navexglobal.com/download/attachments/170797518/NAVEXEngage%20New%20Hire%20Bootcamp%20Deep%20Dive%20Deck.pptx?version=1&modificationDate=1621541842493&api=v2)

- RiskRate: [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/CSO%20Bootcamp%20-%20Day%205-RR.mp4?version=1&modificationDate=1621021204737&api=v2), [Slide Deck](https://confluence.navexglobal.com/download/attachments/170797518/Bootcamp%20Deep%20Dive%20Deck%20-%20RiskRate.pptx?version=1&modificationDate=1621369594707&api=v2)

- Lockpath: [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/CSO%20Bootcamp%20-%20Day%205-Lockpath.mp4?version=1&modificationDate=1621021281733&api=v2)

- NAVEX ESG (*Environmental, Sustainability and Governance*): [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/CSO%20Bootcamp%20-%20Day%205-ESG.mp4?version=1&modificationDate=1621021296733&api=v2)

- COIDisclosures (*Conflict of Interest*): [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/CSO%20Bootcamp%20-%20Day%205-COI%20DM.mp4?version=1&modificationDate=1621021328733&api=v2)

- GRC Insights: (*Governance, Risk Management, and Compliance*) [Intro Video](https://confluence.navexglobal.com/download/attachments/170797518/CSO%20Bootcamp%20-%20Day%205-ESG.mp4?version=1&modificationDate=1621021296733&api=v2)

## Additional Resources

Below is a list of resources that are not required training for the role, but have proven useful to members of the Data Analytics team.

### Confluence

- [Brand Center](https://confluence.navexglobal.com/pages/viewpage.action?pageId=52756824): Website - NAVEX color schemes and brand guidelines. Useful when putting together visualizations, presentations, and documents.

- [Customer Success Organization Home](https://confluence.navexglobal.com/display/CSO2/Customer+Success+Organization+Home): Website - Customer Success Organization resources and organization charts.

- [Multi-Factor Authentication](https://confluence.navexglobal.com/pages/viewpage.action?pageId=98927784): Website - Support and troubleshooting for MFA issues.

### Salesforce

- [Salesforce Reports and Dashboard Generation](https://www.youtube.com/watch?v=dAvqbAz_a-Y): Video - Comprehensive tutorial for Salesforce report and dashboard generation, automation, as well as permissions & security management, edge cases, and more.

- [Make SOQL Queries Selective](https://help.salesforce.com/articleView?id=000325257&type=1&mode=1): Website - Article providing a basic overview of simple techniques to improve the efficiency of Salesforce reports and queries.

### Excel

- [Excel Power Query Course: Power Query Tutorial for Beginners](https://www.youtube.com/watch?v=BrLQmJ1Vqk4): Video - In depth tutorial for Power Query usage inside of Excel.

- [Analyzing Salesforce Data with Excel](https://www.youtube.com/watch?v=hZ0BUzkH0Vk): Video - A brief introduction to the use of Power Query to automatically pull Salesforce data into an Excel workbook.

- [Power Query Demo With Salesforce, Network Folder](https://www.youtube.com/watch?v=UFzOsNZf3Qo&t=141s): Video - Basic tutorial on Power Query usage with Salesforce and files stored on a network drive.

### R

- [R for Data Science](https://r4ds.had.co.nz/): eBook - A great introduction to R and the Tidyverse collection of packages. The online version is free and receives updates as features are added or changed. ISBN: 978-1491910399.

- [Advanced R (Second Edition)](https://adv-r.hadley.nz/index.html): eBook - Additional R functionality, introduces concepts like control flow and modeling strategies. Use with Advanced R Solutions for walk-throughs and examples. The online version is free and receives updates as features are added or changed. ISBN: 978-0815384571.

- [Structuring R Projects](https://www.r-bloggers.com/2018/08/structuring-r-projects/): Blog - A blog post outlining best practice for structuring project files when creating R scripts.

- [Advanced R Solutions](https://advanced-r-solutions.rbind.io/): eBook - Example-based guide to R functionality and modularity, addresses performance troubleshooting, integration and function mechanics in detail. Use with Advanced R. The online version is free and receives updates as features are added or changed. ISBN: 978-1032007502.

- [R Packages](https://r-pkgs.org/): eBook - How to make your R code more portable by creating a package. The online version is free and receives updates as features are added or changed. ISBN: 978-1491910542.

- [Machine Learning with R](https://www.amazon.com/Machine-Learning-techniques-predictive-modeling/dp/1788295862/ref=sr_1_2?dchild=1&keywords=machine+learning+with+R+packt&qid=1614886989&sr=8-2): Book - A dive into Data Mining and Machine Learning algorithms for R. ISBN: 978-1788295864.

- [R Shiny Dashboard](https://rstudio.github.io/shinydashboard/get_started.html): Website - An introduction to the `shinydashboard` package for R, containing sample code for creating interactive dashboards.

- [R Markdown](https://rmarkdown.rstudio.com/lesson-1.html): Website - An introduction to R Markdown.

- [R Markdown: The Definitive Guide](https://bookdown.org/yihui/rmarkdown/): eBook - A complete guide to R Markdown, including advanced features and presentation. ISBN: 978-1138359338.

- [R Markdown Cookbook](https://bookdown.org/yihui/rmarkdown-cookbook/): eBook - Example-based guide to the knitr package and other helpful tools for composing R Markdown documents. ISBN: 978-1000290806.

- [Free Code Camp R Programming Tutorial - Learn the Basics of Statistical Computing](https://www.youtube.com/watch?v=_V8eKsto3Ug): 2-hour YouTube Lesson with downloadable course materials

- `R` can be connected to the Salesforce API via OAuth 2.0. This allows Salesforce data to be queried from within R, with the results being formatted as a data frame. The following script can be used to initially set up the connection and test the functionality:

  ```r
  install.packages("salesforcer") # Run once to install

  library(salesforcer) # Run once per session
  sf_auth() # Run once per session, first execution will require logging into Salesforce via a web browser and granting access

  df <- sf_query("SELECT IsoCode, ConversionRate FROM CurrencyType") # Execute query against Salesforce
  df # Output results, expected result is a data frame containing currency codes and exchange rates
  ```

### Git and GitHub

- [Git and GitHub for Poets](https://www.youtube.com/watch?v=BCQHnlnPusY): Video - An introduction to Git and GitHub without the need to know a programming language.

### Markdown

- [Basic Syntax](https://www.markdownguide.org/basic-syntax/): Website - Basic Markdown syntax documentation.

- [Extended Syntax](https://www.markdownguide.org/extended-syntax/): Website - Extended Markdown syntax documentation, containing tables and task lists.

### Jupyter Notebook

- [A Beginner's Tutorial to Jupyter Notebooks](https://towardsdatascience.com/a-beginners-tutorial-to-jupyter-notebooks-1b2f8705888a): Website - A introduction to Jupyter Notebooks for interactive data analysis.

- On Windows, it is possible to create a desktop shortcut to launch Jupyter Notebook without needing to use the Command Line. This can be done as follows:
  1. On the Windows Desktop: `Right Click` an empty space and select `New` then `Shortcut`.
  2. Set `Location` to: `cmd /k jupyter notebook`. If Python has not been added to the Window PATH, use `cmd /k py -m jupyter notebook` instead.
  3. Set `Name` to: `Jupyter Notebook`.
  4. Once the shortcut has been created: `Right Click` on the icon and select `Properties`.
  5. Set `Start in` to: `%cd%`, allowing Jupyter Notebook to use the shortcut location as the working directory. Any other filepath can be used if a different location is preferred.
  6. Select: `Change Icon` and set it to the `jupyter_notebook.ico` file in `assets` folder of this repository.
