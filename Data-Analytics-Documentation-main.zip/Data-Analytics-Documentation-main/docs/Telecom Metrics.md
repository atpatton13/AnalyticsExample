# Telecom Metrics

These metrics are used by the NAVEX Telecom team, who operate primarily within the `Cases` and `DS Work Task` objects. Cases are raised by Implementation, Professional Services, or Support teams when work is required configuring customer telephone lines. One `Case` may have multiple `DS Work Tasks` containing individual work items.

A caveat to Telecom reporting is that Web Services regularly carry out work on **Telecom** `DS Work Tasks`. This means reporting needs to be built to return **Telecom** Tasks, but not those owned by **Web Services**.

- [Accuracy](#Accuracy)
- [On-Time Completion](#On-Time-Completion)
- [Tasks Opened](#Tasks-Opened)
- [Tasks Closed](#Tasks-Closed)
- [Time to Complete](#Time-to-Complete)

## Accuracy

Accuracy measures the proportion of `DS Work Tasks` that passed Quality Assurance without the need for remediation work. This is tracked using the `Work Task Accuracy` field which will be set to `Fail` if any QA test failed.

- **Object**: `DS Work Tasks`
- **Report Type**: `Cases with DS Work Tasks (Custom)`
- **Field**: `Work Task Accuracy`
- **Time Frame**: `Date Work Task Complete`

| Filter Field                                  | Filter Type  | Value              | Requirement | API Name                                                        |
| :-------------------------------------------- | :----------- | :----------------- | :---------- | :-------------------------------------------------------------- |
| Account: Test Account                         | Equals       | False              | Required    | `Related_Case__r.Account.Test_Account__c`                       |
| Status                                        | Equals       | Complete           | Required    | `Status__c`                                                     |
| Case: DS Resource Team                        | Equals       | Telecom            | Required    | `Related_Case__r.DS_Resource_Team__c`                           |
| Related PSA Resource: Group: Group Name       | Not equal to | Customer Interface | Required    | `Related_PSA_Resource__c.pse__Group__c.Name`                    |
| Work Task Accuracy                            | Equals       | Pass, Fail         | Required    | `Work_Task_Accuracy__c`                                         |
| Date Work Task Complete                       | Equals       | *Time Frame*       | Required    | `Date_Work_Task_Complete__c`                                    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*   | Optional    | `Related_Case__r.Account.Account_Owner_Region_CSO_Reporting__c` |

## On-Time Completion

On-Time Completion measures the proportion of Telecom `DS Work Tasks` that were completed on or before their due date. This is measured using the `Overall Work task On-Time (KPI)` field.

- **Object**: `DS Work Tasks`
- **Report Type**: `Cases with DS Work Tasks (Custom)`
- **Field**: `Overall Work task On-Time (KPI)`
- **Time Frame**: `Date Work Task Complete`

| Filter Field                                  | Filter Type  | Value              | Requirement | API Name                                                        |
| :-------------------------------------------- | :----------- | :----------------- | :---------- | :-------------------------------------------------------------- |
| Account: Test Account                         | Equals       | False              | Required    | `Related_Case__r.Account.Test_Account__c`                       |
| Status                                        | Equals       | Complete           | Required    | `Status__c`                                                     |
| Case: DS Resource Team                        | Equals       | Telecom            | Required    | `Related_Case__r.DS_Resource_Team__c`                           |
| Related PSA Resource: Group: Group Name       | Not equal to | Customer Interface | Required    | `Related_PSA_Resource__c.pse__Group__c.Name`                    |
| Date Work Task Complete                       | Equals       | *Time Frame*       | Required    | `Date_Work_Task_Complete__c`                                    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*   | Optional    | `Related_Case__r.Account.Account_Owner_Region_CSO_Reporting__c` |

## Tasks Opened

Tasks Opened measures the number of individual `DS Work Tasks` opened for Telecom in the given time frame. Cases with multiple `DS Work Tasks` will show as multiple records in this report.

- **Object**: `DS Work Tasks`
- **Report Type**: `Cases with DS Work Tasks (Custom)`
- **Field**: `Record Count`
- **Time Frame**: `Date Work Task Opened`

| Filter Field                                  | Filter Type  | Value              | Requirement | API Name                                                        |
| :-------------------------------------------- | :----------- | :----------------- | :---------- | :-------------------------------------------------------------- |
| Account: Test Account                         | Equals       | False              | Required    | `Related_Case__r.Account.Test_Account__c`                       |
| Case: DS Resource Team                        | Equals       | Telecom            | Required    | `Related_Case__r.DS_Resource_Team__c`                           |
| Related PSA Resource: Group: Group Name       | Not equal to | Customer Interface | Required    | `Related_PSA_Resource__c.pse__Group__c.Name`                    |
| Date Work Task Opened                         | Equals       | *Time Frame*       | Required    | `Date_Work_Task_Opened__c`                                      |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*   | Optional    | `Related_Case__r.Account.Account_Owner_Region_CSO_Reporting__c` |

## Tasks Closed

Tasks Closed measures the number of individual `DS Work Tasks` closed by Telecom in the given time frame. Cases with multiple `DS Work Tasks` will show as multiple records in this report.

- **Object**: `DS Work Tasks`
- **Report Type**: `Cases with DS Work Tasks (Custom)`
- **Field**: `Record Count`
- **Time Frame**: `Date Work Task Complete`

| Filter Field                                  | Filter Type  | Value              | Requirement | API Name                                                        |
| :-------------------------------------------- | :----------- | :----------------- | :---------- | :-------------------------------------------------------------- |
| Account: Test Account                         | Equals       | False              | Required    | `Related_Case__r.Account.Test_Account__c`                       |
| Status                                        | Equals       | Complete           | Required    | `Status__c`                                                     |
| Case: DS Resource Team                        | Equals       | Telecom            | Required    | `Related_Case__r.DS_Resource_Team__c`                           |
| Related PSA Resource: Group: Group Name       | Not equal to | Customer Interface | Required    | `Related_PSA_Resource__c.pse__Group__c.Name`                    |
| Date Work Task Complete                       | Equals       | *Time Frame*       | Required    | `Date_Work_Task_Complete__c`                                    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*   | Optional    | `Related_Case__r.Account.Account_Owner_Region_CSO_Reporting__c` |

## Time to Complete

Time to Complete measures the average time it takes for Telecom tasks to be completed.

- **Object**: `DS Work Tasks`
- **Report Type**: `Cases with DS Work Tasks (Custom)`
- **Field**: `Total Time Work Task Open`
- **Time Frame**: `Date Work Task Complete`

| Filter Field                                  | Filter Type  | Value              | Requirement | API Name                                                        |
| :-------------------------------------------- | :----------- | :----------------- | :---------- | :-------------------------------------------------------------- |
| Account: Test Account                         | Equals       | False              | Required    | `Related_Case__r.Account.Test_Account__c`                       |
| Status                                        | Equals       | Complete           | Required    | `Status__c`                                                     |
| Case: DS Resource Team                        | Equals       | Telecom            | Required    | `Related_Case__r.DS_Resource_Team__c`                           |
| Related PSA Resource: Group: Group Name       | Not equal to | Customer Interface | Required    | `Related_PSA_Resource__c.pse__Group__c.Name`                    |
| Date Work Task Complete                       | Equals       | *Time Frame*       | Required    | `Date_Work_Task_Complete__c`                                    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*   | Optional    | `Related_Case__r.Account.Account_Owner_Region_CSO_Reporting__c` |
