# Migration Services

Location: [sharepoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx)

Cadence: Monthly

Due Date: 7th

## Introduction

The Migration Documentation is where the data for the iLevel **Need link to the iLevel** is gather prior to compilation within the iLevel. There are currently 4 different migrations happening. PolicyTech, AlertLine/Integrilink, Expolink, and Suite Hotline.

## PolicyTech Migration

Finance will need to be sure to address the loading of the data prior to our pulling of the Salesforce document. Do not Start this any sooner than the 2nd business day of the month.

1. Open [Sharepoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx)
2. Open *Migration Workbooks* then open last months folder
    1. Open the PT Migration ARR Roll file
    2. Save as "PT Migration ARR Roll_Jan2020_XXX2021.xlsx"
3. Open the following link: [ARR Roll - PT Migration Reporting](https://navex.lightning.force.com/lightning/r/Report/00O1T000006Bo1xUAC/view?queryScope=userFolders)
4. Ensure the time frame of the filters is set to the previous month
5. Download the data and append it to the bottom of the data in the **ARR Roll** tab
    1. Remove the header row from the data that was just inserted
6. Open the Product Line Customers sheet and insert a new column after the last month
7. Using the data ribbon at the top, refresh all data
8. Start at the last column containing Month data for each of the following steps
9. On the Product Line Customers tab, drag over all formulas from row 1 through 8
10. On the End of Period tab, drag the formulas over in row 19 and 20, 33 and 34
11. On the Churn tab drag the formulas across 2 through 9, 17, 30, and 31
12. On the Sweep tab, drag formulas across rows 2 through 8, 16, 43, 55
    1. Type the month into row 1 as *'Apr-21* with emphasis on the leading apostrophe
13. On the Bookings tab, drag formulas across rows 2 through 9, and 16
    1. Type the month into row 1 as *'Apr-21* with emphasis on the leading apostrophe
14. Open the **Summary Roll** tab and save the document
    1. Type *Act* into the row 4 and then hit "Tab"
    2. Read through the column and make sure there is nothing missing and that the formulas have executed after Act
        1. This may take looking through each cell and making sure, if blank/0, that is the correct output
15. Open the iLevel found in the [Sharepoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx)
16. Open the **Migration Effort** tab
17. % ARR Completed - data is located in [policy tech migration dashboard](https://navex.lightning.force.com/lightning/r/Report/00O1T000006RBwHUAW/view)
    1. Calculation: **Total Opportunity: list** divided by Starting ARR (this is found on "Summary Roll" tab in cell C7)
18. % of ARR Booked – in the reporting tab row 50 [1 – (uncontracted ARR / original ARR )]
19. ARR Remaining to be Booked – it is the uncontracted ARR to be booked from row 50 of the reporting tab
20. Customers Remaining to be Booked - found on row 51 of the reporting tab
21. Customers Churned – found on the Churn tab in the grey bar, row 30
22. Total Churn ARR – found on Summary Roll tab row 19
23. Total Uplift ARR – found on the Summary Roll tab (booking [row 13] + sweep [row 23])
24. Net Retention – Overall –  found on the Reporting tab row 30
25. Net Retention - Year to Date – open the formula for row 30 of the Reporting tab
    1. Double click on the cell
    2. Adjust the cells, encircled in blue, red, and purple to capture the current year, hit enter
    3. Take note of this number, then undo using (ctrl+z)
26. Original Customer Count – found on the Reporting tab row 39 (378)
27. Count of Customers Booked – found on row 52 of Reporting tab
28. Look through the Bookings and Sweep tabs
    1. In the current month column, make sure that for each New there is a Decommission as well
    2. If there is not, look through these and find out why this is
    3. Let Claire in Finance know of any discrepancies found
29. When completed, make sure files are saved and notify Dan Buckwell all changes to the iLevel are completed for the PT Migration
