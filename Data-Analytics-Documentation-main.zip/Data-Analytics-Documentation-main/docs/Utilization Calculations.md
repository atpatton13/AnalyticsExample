# Utilization Calculations

Utilization Calculations are run within Salesforce to calculate the Billable Utilization of each active resource. This allows Billable Utilization reports to be run without needing to analyse large amounts of Work records. `Utilization Calculations` can be accessed in Salesforce via the App Switcher.

## Weekly Calculations

Weekly calculations should be run every **Monday** morning. If this is not possible due to a company holiday, the calculation should be run the next working day.

1. Open the most recent `a. Last Week` calculation.

2. Select the dropdown arrow in the top right of the screen and click `Calculate Utilization`.

3. Set the `Name` to `a. Last Week Ending mm/dd` where *mm/dd* is the previous **Friday**.

4. Ensure `Delete Prior Calculation` is **Unchecked**.

5. Set the `Historic Utilization Start Date` and `End Date` to the previous week. Weeks run from **Sunday** to **Saturday**.

6. Click `Calculate` and leave the browser window open until the calculations are complete. It is common for this process to take at least one hour.

7. Once complete, remove the `a. Last` prefix from the previous week's calculation name.

## Monthly Calculations

Monthly calculations should run every **Monday** and on the **1st** of every month. This allows the calculations to be updated with the month-to-date and final metrics as soon as possible.

1. Open the most recent `d. This Month` calculation.

2. Select the dropdown arrow in the top right of the screen and click `Calculate Utilization`.

3. As calculations are updated periodically throughout the month, and once more at the end, setup for each is slightly different:

    - If the calculation is updating the current month, keep `Name` the same and ensure `Delete Prior Calculation` is **Checked**.

    - If the calculation is for a new month, change `Name` to the current month and ensure `Delete Prior Calculation` is **Unchecked**.

4. Set the `Historic Utilization Start Date` and `End Date` to the current month. If running the calculation during a month, the `End Date` should be set to the previous **Friday**.

5. Click `Calculate` and leave the browser window open until the calculations are complete. It is common for this process to take at least one hour.

6. Once complete, ensure the current and previous month's calculation names are prefixed with the correct code: `c.` for Last Month, and `d.` for This Month. Remove the prefixes from other months if necessary.

    - The prior month calculation `c.` only needs to be run once per month unless there are special circumstances such as the first of the month occurring on a holiday.

## Quarterly Calculations

Quarterly calculations should run every **Monday** and on the **1st** of every month. This allows the calculations to be updated with the quarter-to-date and final metrics as soon as possible.

1. Open the most recent `b. Q to Date` calculation.

2. Select the dropdown arrow in the top right of the screen and click `Calculate Utilization`.

3. As calculations are updated periodically throughout the quarter, and once more at the end, setup for each is slightly different:

    - If the calculation is updating the current quarter, keep `Name` the same and ensure `Delete Prior Calculation` is **Checked**.

    - If the calculation is for a new quarter, change `Name` to the current quarter and ensure `Delete Prior Calculation` is **Unchecked**.

4. Set the `Historic Utilization Start Date` and `End Date` to the current quarter. If running the calculation during a quarter, the `End Date` should be set to the previous **Friday**.

5. Click `Calculate` and leave the browser window open until the calculations are complete. It is common for this process to take at least one hour.

6. Once complete, ensure the current quarter's calculation name is prefixed with `b.`. Remove the prefixes from other quarters if necessary.

## Utilization Codes

In order for different calculation time periods to be displayed on one report, the most recent calculations are prefixed with a specific letter. This letter creates a distinction from previous calculations of the same time period type.

| Code | Time Frame      |
|:-----|:----------------|
| a.   | Last Week       |
| b.   | Quarter to Date |
| c.   | Last Month      |
| d.   | This Month      |
