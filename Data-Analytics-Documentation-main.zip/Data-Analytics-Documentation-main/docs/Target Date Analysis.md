# Target Date Analysis

Location: [SharePoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx?viewid=589ddb82%2D9e47%2D4f78%2Db574%2Dea604178eb7c&id=%2Fsites%2FDataAnalystTeam%2FShared%20Documents%2FTarget%20Date%20Analysis)

Cadence: **Monthly**

Due Date: **2nd Working Day** additional work required on the **9th Calendar Day**

Delivered To: [Doug Kronmiller, Robert Schutte, Joe Patterson, January Vizconde, and Aaron Aab](mailto:dkronmiller@navexglobal.com;rschutte@navexglobal.com;jpatterson@navexglobal.com;JVizconde@navexglobal.com;aaab@navexglobal.com?subject=Target%20Date%20Analysis%20Report)

## Overview

Target Date Analysis is designed to track the accuracy of Target Date predictions on Implementation and Professional Services Milestones. This provides management with a breakdown of the work that was due to be completed in a given month vs the work that was actually completed.

This data is then used to provide additional training to Project Managers where necessary. Target Date predictions are used in revenue forecasting, meaning a higher Target Date Accuracy results in better forecasts and budgets.

## Data Collection and Reporting

### Commit Data (9th Calendar Day)

1. On the 9th of the month after 8am PST, open the previous months TDA folder in [Sharepoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FDataAnalystTeam%2FShared%20Documents%2FTarget%20Date%20Analysis&viewid=589ddb82%2D9e47%2D4f78%2Db574%2Dea604178eb7c)
2. Save the document as the current month: **Target_Date_Analysis_MonthName_2021.xlsx**
3. Open the *Commit Data* tab and delete the data from columns A to W
4. Click on the link in cell AB2 ([IM - TDA Commit](https://navex.lightning.force.com/lightning/r/Report/00O1T000006hOfhUAE/view))
    1. Compare the numbers given in this to the [IM Financial Target Dashboard](https://navex.lightning.force.com/lightning/r/Dashboard/01Z1T000000Me2WUAS/view)
        1. *Sum of Go-Live Revenue* on the commit report is equal to the following: *Future Setup NRR: Current Month* + *Setup NRR: Previous Month* + *Future PS NRR: Current Month* + *PS NRR: Previous Month*
5. Export the data, details only, as .csv and Unicode (UTF-8)
6. Open the downloaded data set
7. Copy and paste the new data into the table for *Commit Data*
8. ***Make sure the number of rows present in the Commit Data csv match the number of rows present in the Commit Data tab of the TDA workbook***
9. Take a screen shot of the **IM - TDA Commit** report and send this to [Doug Kronmiller, Robert Schutte, Joe Patterson, January Vizconde, and Aaron Aab](mailto:dkronmiller@navexglobal.com;rschutte@navexglobal.com;jpatterson@navexglobal.com;JVizconde@navexglobal.com;aaab@navexglobal.com?subject=Target%20Date%20Analysis%20Report) for their review.

### Actual Data (2nd Calendar Day)

1. On the 2nd of the month, open the [Sharepoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FDataAnalystTeam%2FShared%20Documents%2FTarget%20Date%20Analysis&viewid=589ddb82%2D9e47%2D4f78%2Db574%2Dea604178eb7c) previous months folder
2. Open the **Target_Date_Analysis_MonthName_2021.xlsx** file
3. Open the *Actual Data* tab
4. Make sure the data has been deleted from the data
    1. Columns A through W should be empty
5. Open the link in cell AA2 [IM - TDA Actual](https://navex.lightning.force.com/lightning/r/Report/00O1T000006hOezUAE/view)
6. Export the data, details only, as .csv and Unicode (UTF-8)
7. Open the downloaded data set
8. Copy and paste the new data into the table for *Actual Data*
9. Save the file
10. Refresh the data for all pivot tables
11. Check each of the Pivot tables on each tab to make sure the data is following the historical trends
12. Email the document to [Doug Kronmiller, Robert Schutte, Joe Patterson, January Vizconde, and Aaron Aab](mailto:dkronmiller@navexglobal.com;rschutte@navexglobal.com;jpatterson@navexglobal.com;JVizconde@navexglobal.com;aaab@navexglobal.com?subject=Target%20Date%20Analysis%20Report) for their review.

### Current Issues and Cases

1. The Commit Target Date has not been updating via the script setup by Business Systems. Samantha Vandehey has a case currently open and is looking in to why this might be happening (10/22/2021)
    1. If this does happen, adjust the pivot tables to use the *Target Date* field instead
