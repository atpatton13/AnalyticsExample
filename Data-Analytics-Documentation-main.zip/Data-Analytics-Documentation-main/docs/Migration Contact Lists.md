# Migration Services

Location: [sharepoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx)

Cadence: Monthly

Due Date: Upon Request, usually the last week of the month

## Introduction

Migration Contact Lists for each Migration Wave are generated from Salesforce using a query written in R and contained within a jupyter notebook file. The output is a workbook with tabs for each wave, containing lists of Alert Contacts of Accounts that meet the criteria outlined by the Migrations team.

## Platform Migration

The purpose of this output is to identify which Customers are eligible for Migration to Platform on a particular product and which Active Contacts for that Customer should be contacted to initiate the migration effort. Criteria for Waves are defined by the Migration Team, and can be subset from the broader list of all eligible Customer Accounts by filter criteria such as:

- *EthicsPoint Platform Migration-eligible Customers with only EthicsPoint Assets On Maintenance or Pre-Maintenance*
- *EthicsPoint Platform Migration-eligible Customers with only EthicsPoint and PolicyTech Assets On Maintenance or Pre-Maintenance*
- *EthicsPoint Platform Migration-eligible Customers with only EthicsPoint and NAVEX Engage Assets On Maintenance or Pre-Maintenance*

Alert Contacts for a particular product may be identified using product-specific Alert Contact fields, or by querying the Account Contact Role record that corresponds to that Contact Record and identifying them based on the Role field's value.

## Steps for generating output:
1. Clone [Project Notebooks](https://github.com/NAVEX-Analytics/Project-Notebooks/tree/main/notebooks) to your local GitHub repository
2. Open jupyter in command prompt with ```jupyter notebook ```
3. Navigate to the local Project Notebooks repository within jupyter and open Platform Migration Contact Lists.ipynb
4. Run all cells. This will likely need to be done more than once if this was the first time running the ```sf_auth()``` function in the kernel that day
5. Open [Sharepoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx), navigate to **Projects > NAVEX One Migration Workbooks > Migration Contact Lists** and confirm an output file has been written to the folder beginning with today's date.