# Customer Support Metrics

These metrics are used by the Customer Support department within NAVEX. Customer Support teams primarily operate within the `Cases` object, which are usually raised via email or the NAVEX Community.

- [Backlog](#Backlog)
- [Cases Opened](#Cases-Opened)
- [Cases Closed](#Cases-Closed)
- [Customer Satisfaction](#Customer-Satisfaction)
- [Initial Response Time](#Initial-Response-Time)
- [Resolution Time](#Resolution-Time)

## Customer Support Nuances

- The majority of Customer Support `Cases` are linked to the relevant customer `Account` within Salesforce. In limited circumstances the Case will be tied to the [NAVEX](https://navex.lightning.force.com/lightning/r/Account/0015000000iMvunAAC/view) Account which can be included in reporting using `Account: 18 Digit AccountId` **0015000000iMvunAAC**.

- If a Customer Support `Case` requires a change in product functionality, the field `Case: Defect / Enhancement` is checked. As work on these Cases is carried out by Product Engineering and not Customer Support, these Cases may be open for a long time. To prevent these Cases skewing Customer Support metrics, they are not included in metrics that track Cases currently open, or closed.

## Backlog

Customer Support Backlog measures the number of Customer Support cases that are currently open. An offset of 48 hours is used to remove cases that are immediately closed upon action, such as password resets. This prevents dramatic variation when looking at this metric at different times of day.

- **Object**: `Cases`
- **Report Type**: `Cases (Custom)`
- **Field**: `Record Count`

| Filter Field                                  | Filter Type  | Value                     | Requirement |
|:----------------------------------------------|:-------------|:--------------------------|:------------|
| Account: Test Account <br />&emsp; *or* Account: 18 Digit AccountId | Equals<br />Equals| False<br />0015000000iMvunAAC| Required    |
| Case Record Type                              | Equals       | Customer Support Requests | Required    |
| Closed                                        | Equals       | False                     | Required    |
| Status                                        | Not equal to | Duplicate                 | Required    |
| Age                                           | Greater than | 48                        | Required    |
| Defect / Enhancement                          | Equals       | False                     | Required    |
| Customer Support Team                         | Equals       | *Products to include*     | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*          | Optional    |

## Cases Opened

Cases Opened measures the number of Customer Support cases opened in a given time frame.

- **Object**: `Cases`
- **Report Type**: `Cases (Custom)`
- **Field**: `Record Count`
- **Time Frame**: `Date/Time Opened`

| Filter Field                                  | Filter Type  | Value                     | Requirement |
|:----------------------------------------------|:-------------|:--------------------------|:------------|
| Account: Test Account <br />&emsp; *or* Account: 18 Digit AccountId | Equals<br />Equals| False<br />0015000000iMvunAAC| Required    |
| Case Record Type                              | Equals       | Customer Support Requests | Required    |
| Date/Time Opened                              | Equals       | *Time Frame*              | Required    |
| Status                                        | Not equal to | Duplicate                 | Required    |
| Customer Support Team                         | Equals       | *Products to include*     | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*          | Optional    |

## Cases Closed

Cases Closed measures the number of Customer Support cases closed in a given time frame.

- **Object**: `Cases`
- **Report Type**: `Cases (Custom)`
- **Field**: `Record Count`
- **Time Frame**: `Date/Time Closed`

| Filter Field                                  | Filter Type  | Value                     | Requirement |
|:----------------------------------------------|:-------------|:--------------------------|:------------|
| Account: Test Account <br />&emsp; *or* Account: 18 Digit AccountId | Equals<br />Equals| False<br />0015000000iMvunAAC| Required    |
| Case Record Type                              | Equals       | Customer Support Requests | Required    |
| Date/Time Closed                              | Equals       | *Time Frame*              | Required    |
| Closed                                        | Equals       | True                      | Required    |
| Status                                        | Not equal to | Duplicate                 | Required    |
| Defect / Enhancement                          | Equals       | False                     | Required    |
| Customer Support Team                         | Equals       | *Products to include*     | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*          | Optional    |

## Customer Satisfaction

Customer Support Customer Satisfaction measures customer sentiment towards NAVEX service on a scale of 0-10 after the resolution of a support case.

- **Object**: `Survey Results`
- **Report Type**: `Survey (Custom)`
- **Fields**: Customer Support: `Q1. Technical Assist`, Product: `Q4. Product Satisfaction`
- **Time Frame**: `Survey Completed`

| Filter Field                                  | Filter Type  | Value                 | Requirement |
|:----------------------------------------------|:-------------|:----------------------|:------------|
| Account: Test Account                         | Equals       | False                 | Required    |
| Survey Completed                              | Equals       | *Time Frame*          | Required    |
| Exclude from Reporting                        | Equals       | False                 | Required    |
| Q1. Technical Assist                          | Not equal to | ""                    | Required    |
| Q4. Product Satisfaction                      | Not equal to | ""                    | Required    |
| Team                                          | Equals       | *Products to include* | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*      | Optional    |

## Initial Response Time

Initial Response Time measures the time it takes for first contact to be made with a customer once a Customer Support case has been created.

- **Object**: `Case Milestones`
- **Report Type**: `Cases with Milestones`
- **Field**: `Elapsed Time (Hours)`
- **Time Frame**: `Date/Time Opened`

| Filter Field                                  | Filter Type  | Value                     | Requirement |
|:----------------------------------------------|:-------------|:--------------------------|:------------|
| Account: Test Account                         | Equals       | False                     | Required    |
| Case Record Type                              | Equals       | Customer Support Requests | Required    |
| Date/Time Opened                              | Equals       | *Time Frame*              | Required    |
| Status                                        | Not equal to | Duplicate                 | Required    |
| Milestone                                     | Equals       | Initial Response          | Required    |
| Customer Support Team                         | Equals       | *Products to include*     | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*          | Optional    |

## Resolution Time

Resolution Time measures the average time for Customer Support cases to be completed.

- **Object**: `Case Milestones`
- **Report Type**: `Cases with Milestones`
- **Field**: `Elapsed Time (Hours)`
- **Time Frame**: `Date/Time Closed`

| Filter Field                                  | Filter Type  | Value                     | Requirement |
|:----------------------------------------------|:-------------|:--------------------------|:------------|
| Account: Test Account                         | Equals       | False                     | Required    |
| Case Record Type                              | Equals       | Customer Support Requests | Required    |
| Date/Time Closed                              | Equals       | *Time Frame*              | Required    |
| Closed                                        | Equals       | True                      | Required    |
| Status                                        | Not equal to | Duplicate                 | Required    |
| Defect / Enhancement                          | Equals       | False                     | Required    |
| Milestone                                     | Equals       | Resolution                | Required    |
| Customer Support Team                         | Equals       | *Products to include*     | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals       | *Account region*          | Optional    |
