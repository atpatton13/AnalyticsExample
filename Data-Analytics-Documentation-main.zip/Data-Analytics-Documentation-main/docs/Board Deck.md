# Board Deck

Location: [SharePoint](https://navex.sharepoint.com/:x:/s/DataAnalystTeam/ERL8U4SIYvtAq0KnD2CbFrYBaLZXsWnRmmUiYwcm5owhWw?e=CQitWZ)

Cadence: **Quarterly**

Due Date: **TBD per Laura**

Delivered To: [Laura Miles](LMiles@navex.com)

## Preface

This document contains the information needed to complete the Data Analytics slides in the quarterly CSO Board Deck.

Unlike other reporting, the Board Deck is not owned by the Data Analytics team. Instead, a new version will be created and distributed at the start of each quarter by **Laura Miles**. 

Due to frequent changes in Board Deck content, these slides may change from quarter to quarter. If this does happen, this document should be updated.

## Contents

- [General Guidance](#general-guidance)
- [Professional and Implementation Services 4Box](#professional-and-implementation-services-4box)
- [Professional Services KPI Chart](#professional-services-kpi-chart)
- [Implementation KPI Chart](#implementation-kpi-chart)
- [NAVEX One Platform Migration Status](#navex-one-platform-migration-status)
- [Customer Support and Success 4Box](#customer-support-and-success-4box)
- [Customer Support KPI Chart](#customer-support-kpi-chart)
- [Customer Success KPI Chart](#customer-success-kpi-chart)
- [NAVEX IRM 4Box](#navex-irm-4box)
- [NAVEX One Eligibility Summary](#navex-one-eligibility-summary)

## General Guidance

- Charts generated in Excel should be set to the correct size before being copied. This can help prevent scaling issues making text and visuals blurry.
- Charts should be copied into Excel as a static image to prevent accidental changes being made.
- Instances of the same metric should match between slides.

## Professional and Implementation Services 4Box

4Box slides contain a high level overview of organizational Highlights, Lowlights, Metrics, and Forward-Looking Priorities. The Data Analytics team only needs to provide data for the **Metrics** section.

- **Services Bookings** is obtained from the **CSO P&L** document as a total of Implementation and Professional Services Bookings.
- **Services GAAP Revenue** is obtained from the **CSO P&L** document as a total of Implementation and Professional Services Revenue.
- **Professional Services Gross Margin** - is obtained from the **CSO P&L** document.
- **Services Qualified Leads Booked** is obtained from the **CSO iLevel** as a total of the Implementation and Professional Services **Qualified Leads Booked** for the previous quarter.
- **Services Billable Utilization** is calculated in the [Services Utilization Report](https://navex.lightning.force.com/lightning/r/Report/00O1T000006Zq99UAC/view).
- **Services CSAT** is calculated in the [Services CSAT Report](https://navex.lightning.force.com/lightning/r/Report/00OHs000006rPeGMAU/view) by adding the ```Total Imp Comp q3``` and ```Total PS Comp q3``` and dividing by the ```Total Count```.

<img src="../assets/screenshots/services_4box.png" align="center" width="600" />

## Professional Services KPI Chart

The Professional Services KPI Chart slide is populated with a screenshot of the **Professional Services KPI Tab**. This screenshot should contain the Professional Services metrics for the **Quarter** and **Year to Date**.

<img src="https://github.com/NAVEX-Analytics/Data-Analytics-Documentation/assets/95381187/63479ec9-b0d8-4f0b-a269-d86d725bd61d" width = "600">

## Implementation KPI Chart

The Implementation KPI Chart slide is populated with a screenshot of the **Implementation KPI Tab**. This screenshot should contain the Implementation metrics for the **Quarter** and **Year to Date**.

<img src="https://github.com/NAVEX-Analytics/Data-Analytics-Documentation/assets/95381187/4175f514-c7ed-4854-9c26-d41bba4208ad" width = "600">

## NAVEX One Platform Migration Status

The NAVEX One Migration Status slide is populated with a screenshot of the NAVEX One migration Salesforce Dashboard. [NAVEX One Platform Dashboard](https://navex.lightning.force.com/lightning/r/Dashboard/01Z1T000001KIzNUAW/view).

<img src="../assets/screenshots/navex_one_metrics.png" align="center" width="600" />

## Customer Support and Success 4Box

The Customer Support and Success 4Box slide follows the same structure as the Services one but focuses on Customer Support and Customer Success Management.

- **Net Promoter Score** is found in the [NPS Dashboard](https://navex.lightning.force.com/analytics/dashboard/0FK1T000000U6aAWAS) by changing the date to ```Previous Quarter```.
- **Customer Support Utilization** is calculated in the [Customer Support Utilization Report](https://navex.lightning.force.com/lightning/r/Report/00O1T000006ZqB0UAK/view).
- **Customer Support CSAT** is calculated in the [Customer Support CSAT Report](https://navex.lightning.force.com/lightning/r/Report/00O1T000006ZrHTUA0/view).
- **Customer Support Qualified Leads Booked** is obtained from the **CSO iLevel** as a total of Customer Support Qualified Leads Booked for the previous quarter.
- **Customer Success Qualified Leads Booked** is obtained from the **CSO iLevel** as a total of Customer Success Qualified Leads Booked for the previous quarter.
- **Quarterly Churn** is obtained from **Finance Monthly Churn Reporting**, where the QTD is the average of 3-month **Total Churn** (also updated in the **CSO iLevel**), the **FCST** originating from the **KPI BOD** *Customer Support - Total Churn - Target* column, and the **YTD** Churn an average of the current year's monthly churn values. 

<img src="../assets/screenshots/support_4box.png" align="center" width="600" />

## Customer Support KPI Chart

The Customer Support KPI Chart slide is populated with a screenshot of the **Customer Support KPI Tab**. This screenshot should contain the Customer Support metrics for the **Quarter** and **Year to Date**.

<img src="https://github.com/NAVEX-Analytics/Data-Analytics-Documentation/assets/95381187/dc764b25-537f-4b11-8f76-214fcb2a768e" width = "600">

## Customer Success KPI Chart

The Customer Success KPI Chart slide is populated with a screenshot of the **Customer Success KPI Tab**. This screenshot should contain the Customer Success metrics for the **Quarter** and **Year to Date**.

<img src="https://github.com/NAVEX-Analytics/Data-Analytics-Documentation/assets/95381187/54fc5c8b-77a7-4b2b-b83e-37b3d365b7f0" width = "600">

## NAVEX IRM 4Box

The NAVEX IRM 4Box slide follows the same structure as the Services one but focusses on the NAVEX IRM product.

- **PS & LVA Services Bookings** is obtained from the **Lockpath P&L** document as a total of the PS and LVA Bookings.
- **Professional Services Revenue** is obtained from the **Lockpath P&L** document.
- **Professional Services Billable Utilization** is obtained from the Salesforce report: [BOD - Lockpath Utilization](https://navex.lightning.force.com/lightning/r/Report/00O1T000006ZrO0UAK/view). 
- **Customer Support Billable Utilization** is obtained from the Salesforce report: [BOD - Lockpath Utilization](https://navex.lightning.force.com/lightning/r/Report/00O1T000006ZrO0UAK/view).
- **Customer Support CSAT** is obtained from the Salesforce report: [BOD - Lockpath CSAT](https://navex.lightning.force.com/lightning/r/Report/00O1T000006ZrO1UAK/view)

<img src="../assets/screenshots/lockpath_4box.png" align="center" width="600" />

## NAVEX One Eligibility Summary

The NAVEX One Eligibility Summary slide is populated with a screenshot of the Output tab of the **[NAVEX One Eligibility Summary](https://navex.sharepoint.com/:x:/s/DataAnalystTeam/EVjrdaJZ78JFtnvl6ffvKX0BPaCtXGhW5Ye-d4Y31a5xyQ?e=v1iM82)**. First Clone this repository and run **[MigrationEligibilitySummary.R](scripts)** to update the workbook in SharePoint.

<img src="../assets/screenshots/NAVEXOneEligibilitySummary.png" align="center" width="600" />
