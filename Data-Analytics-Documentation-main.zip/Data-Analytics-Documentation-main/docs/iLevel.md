# iLevel

Location: [SharePoint](https://navex.sharepoint.com/:x:/s/DataAnalystTeam/EeHKdkiW2oJJjqAEQVs_OhIBljIP9lto4AQxb6HkZ2Z6fg)

Cadence: **Monthly**

Due Date: **5th Working Day** (Review Copy), **8th Working Day** (Final Copy)

Delivered To: **Customer Success Organization Executives**, **Directors**, and **Senior Managers**

## Introduction

The Customer Success Organization ilevel is a monthly deliverable that summarizes departmental metrics from across CSO in a tabular format. This allows management to track team performance over time while providing oversight to executive leadership. The majority of data is compiled by the Data Analytics team, with some metrics being provided by Finance.

Prior to publishing the final copy of the iLevel on the **8th** working day of the month, a review copy is sent to **Directors** and **Senior Managers** on the **5th** working day. This provides an opportunity for queries and amendments to be made before metrics are presented at an executive level.

## Layout

Within the Customer Success Organization, there are multiple iLevels that are published each month. These are all contained in the same Excel document on different tabs. Metrics between the iLevels are generally the same but constrained to one area of the product or Market.

- **NG Core** - The primary CSO iLevel looking at the core NAVEX products.

- **International** - The same as the NG Core iLevel but restricted to customers in the International market. These customers can be identified using the `Account: Account Reporting Region` field equals `International`. These figures are included in NG Core values.

- **Migration Services** - Reports on Migration Services metrics for all current product migration initiatives. These figures are not included in NG Core values.

- **Lockpath** - Metrics relating to Lockpath customers and products. These figures are not included in NG Core values.

- **WhistleB** - Metrics relating to WhistleB customers and products. These figures are not included in NG Core values.

Columns in each iLevel tab are identical with each used to display the following information.

- **Name** - Metric category.

- **Metric** - Name of metric. Where a Salesforce report is used to obtain the metric, the name serves as a hyperlink.

- **Target** - Target set by team management. Color coded based on the current month's value. Above Target: `#C6E0B4` (Green, Accent 6, Lighter 60%), Below Target: `#F8CBAD` (Orange, Accent 2, Lighter 60%).

- **3 Months Trending** - Excel Sparkline displaying current and previous 2 months values.

- **Months** - Metric values for the current and previous 12 months. Only months should be hidden so they are available at a later date.

- **Author** - *Hidden in final version*. Name of the Data Analyst responsible for the metric.

- **SD from Mean** - *Hidden in final version*. Measures the number of standard deviations the current month's value is from the mean of the previous 12 months. Metrics more than 3 standard deviations from the mean will be highlighted red and may require addition investigation to ensure they are correct.

## Setup

As the iLevel is a live document, the existing document is updated each month. This allows one document to be referenced for all data current and historic data. Before new data can be added for a given month, the following steps need to be undertaken on each tab:

1. Insert a new column after the previous one, adding the month and adjusting cell boards where necessary.

2. Set the color of all targets to Grey `#D9D9D9` (White, Background 1, Darker 15%).

3. Move the Sparklines to the current month. Right Click Sparkline -> Sparklines -> Edit Group Location & Data -> Change Date Range to cover the Current and Previous 2 Months.

4. Hide previous months where necessary to ensure only the current and previous 12 months are shown.

5. Unhide the Author and SD from Mean columns after the current month.

6. Change the SD from Mean formula to compare the current month to the previous 12 months. Drag down as necessary to apply to all rows.

7. Repeat for all tabs in the iLevel document.

## Compilation

It is often the case that not all bookings will be processed by the end of the month. For this reason, some iLevel metrics cannot be calculated until after the **3rd working day** of the month. This ensures teams such as Finance and Resource Management have sufficient time to ensure all activity has been finalized.

Once the 3rd working day of the month has passed, metrics can be calculated and imported into the iLevel. In many cases these can be obtained via a Salesforce report that is linked in the metric name. This allows for quick reference and provides viewers with the raw data if necessary. Where appropriate, comments are included in the metric name for greater clarification on how they are to be calculated.

Where a metric has a target, the background color of the cell should be updated based on the new value. Above Target: `#C6E0B4` (Green, Accent 6, Lighter 60%), Below Target: `#F8CBAD` (Orange, Accent 2, Lighter 60%). If a metric is missing or not applicable in the current month, the target cell should remain Grey `#D9D9D9` (White, Background 1, Darker 15%).

Some metrics are obtained outside of Salesforce or are provided by other departments:

- **Customer Churn** - Provided by Finance in the `Churn` workbook. Typically emailed around the **6th** working day of the month.

- **Services Financials** and **Expense, % of Revenue**  - Provided by Finance in the `CSO P&L` workbook. Typically emailed around the **10th** working day of the month. Lockpath has a separate P&L document which is usually sent at a later date.

- **Customer Success Management** - Provided by Finance in the `Operations KPI` workbook. Typically emailed around the **12th** working day of the month.

- **NAVEX Community** - Obtained via [Google Analytics](https://analytics.google.com/analytics/web/) and the [NAVEX Community Metrics](https://navex.lightning.force.com/lightning/r/Dashboard/01Z1T0000011euVUAQ/view) Salesforce dashboard.
