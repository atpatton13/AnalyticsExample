# Migration Services Metrics

These metrics are used by Migration Services to track the status of customers as they are migrated between products. Many of the Migration Services metrics are identical to those used by Implementation and Professional Services. They can usually be calculated in the same way, with a filter to limit them to migration Opportunities, Projects, and Milestones.

- [Remaining ARR](#Remaining-ARR)
- [Churn](#Churn)
- [Migration Opportunities](#Migration-Opportunities)
- [Migration Projects](#Migration-Projects)
- [Customer Satisfaction](#Customer-Satisfaction)
- [Template](#Template)

## Remaining ARR

Remaining ARR is the amount of Annual Recurring Revenue that remains on the legacy product.

- **Object**: `Assets`
- **Report Type**: `Assets - Custom`
- **Field**: `ARR (Converted)`

| Filter Field          | Filter Type | Value                                            | Requirement |
|:----------------------|:------------|:-------------------------------------------------|:------------|
| Account: Test Account | Equals      | False                                            | Required    |
| Asset Status          | Equals      | Pre-Maintenance, On Maintenance, Off Maintenance | Required    |
| Product Family        | Equals      | *Legacy product family*                          | Required    |

## Churn

Churn measures the amount of ARR that was lost due to customers choosing to leave NAVEX rather than migrate to the new product.

- **Object**: `Asset History`
- **Report Type**: `Asset History with Asset`
- **Field**: `Change in ARR (Converted)`
- **Time Frame**: `Churn Transaction Date`

| Filter Field            | Filter Type  | Value                   | Requirement |
|:------------------------|:-------------|:------------------------|:------------|
| Account: Test Account   | Equals       | False                   | Required    |
| Type                    | Not equal to | Period End              | Required    |
| ARR Changed             | Equals       | True                    | Required    |
| Churn Indicator         | Equals       | True                    | Required    |
| Asset: Migration Effort | Equals       | *Migration Effort*      | Required    |
| Decommission Type       | Equals       | Cancellation, Reduction | Optional    |

## Migration Opportunities

Used to track migration opportunities.

- **Object**: `Opportunities`
- **Report Type**: `Opp (Custom)`

| Filter Field          | Filter Type      | Value                                           | Requirement |
|:----------------------|:-----------------|:------------------------------------------------|:------------|
| Account: Test Account | Equals           | False                                           | Required    |
| Migration Effort      | Equals           | *Migration effort*                              | Required    |
| Primary Reason Closed | Not equal to     | Duplicate Opportunity                           | Required    |
| Opportunity Name      | Does not contain | Addition, SKU, Licence, License                 | Required    |
| Order Sub-Type        | Equals           | Platform Consolidation, Migration Consolidation | Optional    |

**Note**: `Order Sub-Type` can be used to differentiate between Migration Services (*Platform Consolidation*) and Sales (*Migration Consolidation*) opportunities.

## Migration Projects

Uses to track migration projects.

- **Object**: `Opportunities`
- **Report Type**: `Opp (Custom)`

| Filter Field                       | Filter Type      | Value                                           | Requirement |
|:-----------------------------------|:-----------------|:------------------------------------------------|:------------|
| Account: Test Account              | Equals           | False                                           | Required    |
| Opportunity: Migration Effort      | Equals           | *Migration effort*                              | Required    |
| Opportunity: Primary Reason Closed | Not equal to     | Duplicate Opportunity                           | Required    |
| Opportunity: Opportunity Name      | Does not contain | Addition, SKU, Licence, License                 | Required    |
| Opportunity: Stage                 | Equals           | Booked                                          | Required    |
| Assigned Date                      | Not equal to     | ""                                              | Required    |
| Opportunity: Order Sub-Type        | Equals           | Platform Consolidation, Migration Consolidation | Optional    |

## Customer Satisfaction

Customer Satisfaction measures sentiment towards NAVEX upon the successful completion of a migration project. Customers provide a score between 0 and 10 for both the project and project manager.

- **Object**: `Survey Results`
- **Report Type**: `Survey (Custom)`
- **Fields**: `Q2. Migration Team Overall`
- **Time Frame**: `Survey Completed`

| Filter Field                  | Filter Type | Value                 | Requirement |
|:------------------------------|:------------|:----------------------|:------------|
| Account: Test Account         | Equals      | False                 | Required    |
| Survey Completed              | Equals      | *Time Frame*          | Required    |
| Exclude from Reporting        | Equals      | False                 | Required    |
| Delivery Survey Type          | Equals      | Migration Completion  | Required    |
| Opportunity: Migration Effort | Equals      | *Migration effort*    | Required    |

**Note:** Customer Satisfaction scores that are `null` should be removed in Salesforce before summarizing otherwise they will be treated as 0. This may require different survey types to be calculated in separate reports.
