# Capacity Planning - Data Services

Location: [DS - Capacity Planning](https://navex.sharepoint.com/:x:/s/DataAnalystTeam/EfNhOBh0GWJDjtzyt6xHEPkBdd1n2JuDTPoELPlNi247ig?e=nef4xk)

Cadence: **Yearly**

Deliver to: Jennifer White and Troy Dickson

## Introduction

This document is used to track the amount of hours that are spent by the DS team on cases that are submitted by other groups, the server location of the accounts being worked on, hours by specific product, and the hours by project groups.

This document will assist in the planning of head count in the future for the DS team. Using the metrics above, it is possible to calculate the needed number of individuals per team. Since there are approximately 2080 hours per calendar year per person to work, the total hours worked by them team divided by 2080 gives the optimal head count.

The hours worked on cases submitted by other departments will increase the awareness of managers to possibly cross train to increase efficiency of case management and the speed at which these cases are resolved in the future.

## Process

1. Open Salesforce report [DS - Capacity Planning](https://navex.lightning.force.com/lightning/r/Report/00O1T000006Zr2nUAC/view)
2. Adjust the time frame to the previous year
    1. With the changes in Data Services July 1 of 2021, this report may need to be adjusted
3. Export the file as a .csv
4. Delete the old data on the RAW data tab of the excel document in columns A - Z
5. Resize the table to ensure there are no blanks left at the end of the table
6. Paste the new data into the table
7. Refresh all the data for the tables using the data ribbon at the top
8. Save the document as **DS_Capacity_Planning_YYYY.xlsx**
9. Send results to Jennifer and Troy
