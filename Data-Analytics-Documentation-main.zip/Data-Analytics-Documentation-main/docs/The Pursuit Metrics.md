# The Pursuit Metrics
[The Pursuit](https://navex.lightning.force.com/lightning/r/Dashboard/01ZHs000000tkwQMAQ/view?queryScope=userFolders) tracks Upsells and Cross-sells created by employees in the CSO. The employee with the highest Upsell SQL Amount referrals and employee with highest Cross-sell SQL Net ARR referrals earn a place in Presidents Club. 

### Definitions:

**Upsell:** Opportunity within existing product where `Count CrossSell SPF` == 0; Uses `Amount` as value.

**Cross-sell:** Opportunity for an additional Super Product Family where `Count CrossSell SPF` >= 1; Uses `Net ARR` as value.

**SQL:** Sales Qualified Lead where the opportunity has moved beyond 25% probability. 

### Contest Qualifications

**All Opportunities**
- `Manager Validated SQL` == True
- New opportunties should convert to SQL in 90 days or less. The date it converted to an SQL is in the `SQL Date - FCI` field.
- `Created Date` >= October 1 before contest year
- `Services Lead Source` does not contain Client Request, NULL
- `Order Sub-Type` != Multi-Account Transaction (MAT)

**Upsells**
- `Containing Products` does not contain 1010641, 1010640, 1010644, TR-BC-POL-01, TR-BC-POL-LM, SW-PM-PPM-043, SW-PM-PPM-044, SW-PM-PPM-046, SW-PM-PPM-035, SW-PM-PPM-031, SW-3P-3P-015, SW-PM-TPS-003, SW-PM-TPS-006, 
SW-PM-TPS-009, SW-CM-CMP-001, SW-PM-PPM-008, SW-CM-CMF-003, SW-PM-PPM-005, SW-CM-CMD-080, SW-CM-CMF-001, SW-PM-PPM-010, SW-CM-CME-004, 102302, SW-CM-CME-001, SW-PM-PPM-003, SW-CM-CMP-002, SW-CM-CMP-003, SW-CM-CMD-083,
SW-PM-PPM-006, SW-CM-CMD-078, SW-CM-CME-003, SW-PM-PPM-001, SW-PM-PPM-009, SW-CM-CME-002, SW-CM-CMD-082, SW-PM-PPM-055, SW-PM-PPM-068, SW-TR-OVG-001
- `Amount` > 0

**Cross-sells**
- `ARR Net` > 0 

### Key Metrics:

**Upsell SQL:** Sum of Upsell opportunity `Amount` with `SQL Date - FCI` during requested time frame

**Cross-sell SQL:** Sum of Cross-sell opportunity `ARR Net` with `SQL Date - FCI` during requested time frame

[**Total SQL:**](https://navex.lightning.force.com/lightning/r/Report/00OHs000009tpNMMAY/view?queryScope=userFolders) Sum of Upsell opportunity `Amount` and Cross-sell opportunity `ARR Net` with `SQL Date - FCI` during requested time frame

[**% Upsells moved to SQL:**](https://navex.lightning.force.com/lightning/r/Report/00OHs000009tpNXMAY/view?queryScope=userFolders) (Count of Upsell opportunities with `SQL Date - FCI` before end of time frame) / (Count of Upsell opportunties with `Created Date` within 90 days of contest year and before end of time frame) 

[**% Cross-sells moved to SQL:**](https://navex.lightning.force.com/lightning/r/Report/00OHs000009tpNWMAY/view?queryScope=userFolders) (Count of Cross-sell opportunities with `SQL Date - FCI` before end of time frame) / (Count of Cross-sell opportunties with `Created Date` within 90 days of contest year and before end of time frame) 

**Total Upsell Pipeline:** Sum of Upsell opportunities `Amount` with `Created Date` in time frame

**Total Cross-sell Pipeline:** Sum of Cross-sell opportunities `ARR Net` with `Created Date` in time frame

[**Total Pipeline:**](https://navex.lightning.force.com/lightning/r/Report/00OHs000009tpNvMAI/view?queryScope=userFolders) Sum of Upsell opportunity `Amount` and Cross-sell opportunity `ARR Net` with `Created Date` in time frame

**Total Upsell Booked:** Sum of Upsell opportunity `Amount` with `Stage` as *Closed Won* or *Booked* and `Close Date` in time frame

**Total Cross-sell Booked:** Sum of Cross-sell opportunities `ARR Net` with `Stage` as *Closed Won* or *Booked* and `Close Date` in time frame

[**Total Booked:**](https://navex.lightning.force.com/lightning/r/Report/00OHs000009tpMxMAI/view?queryScope=userFolders) Sum of Upsell opportunity `Amount` and Cross-sell opportunity `ARR Net` with `Stage` as *Closed Won* or *Booked* and `Close Date` in time frame
