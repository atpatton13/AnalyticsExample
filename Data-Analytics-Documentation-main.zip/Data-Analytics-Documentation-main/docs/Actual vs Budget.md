# Actual VS Budget

This document is used to compare the actual months numbers verses what was budgeted out for that time frame. We will be in charge of inputting two metrics for PSO and Implementation. Headcount and Actual Utilization Rate.

Cadence: **Monthly**

Due Date: *TBD*

Location: [Actual vs Budget](https://navex.sharepoint.com/:x:/g/EcjBLF0sSOdGluzlhLXv2xoBHD-13ZOzUaBt0gZ8HM7U8g?e=ygxhz9)

1. Open the shared document from above.

2. Row 18 of the *Implementation* tab is the same metric we have in the iLevel. Use the iLevel to retrieve the metric and input it here.

3. Productive headcount, row 19, is calculated from the following reports (Headcount is people that are not excluded from time calculations and are not onboarding at the end of the month):

    1. [Implementation](https://navex.lightning.force.com/lightning/r/Report/00O1T000006hDmIUAU/view)
    2. [Professional Services](https://navex.lightning.force.com/lightning/r/Report/00O1T000006hDmXUAU/view)
    3. [Web Services](https://navex.lightning.force.com/lightning/r/Report/00O1T000006hFUGUA2/view)
    4. [Technical Specialist](https://navex.lightning.force.com/lightning/r/Report/00O1T000006hFULUA2/view)
    5. [Telecom](https://navex.lightning.force.com/lightning/r/Report/00O1T000006hFUHUA2/view)

4. On the Implementation tab of the **Actual vs Budget** document, input the Active headcount for the month from the `Implementation` report above.

5. In the PSO tab of the **Actual vs Budget** document, input the active headcount from the `Professional Services` report above.
