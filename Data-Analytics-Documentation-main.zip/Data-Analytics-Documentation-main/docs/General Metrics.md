# General Metrics

These metrics are consistent across multiple departments within the NAVEX Customer Success Organization.

- [ARR at Risk](#ARR-at-Risk)
- [Billable Utilization](#Billable-Utilization)
- [Net Promoter Score](#Net-Promoter-Score)
- [Issues Opened](#Issues-Opened)
- [Issues Closed](#Issues-Closed)
- [Upsell](#Upsell)

## ARR at Risk

ARR at Risk measures the amount of Annual Recurring Revenue (ARR) that is currently at risk of churning due to open Red or Yellow issues. ARR should be counted once per customer for the highest priority issue.

- **Object**: `Issues`
- **Report Type**: `Issues (Custom)`
- **Field**: `Total Asset ARR (Converted)`

| Filter Field                                  | Filter Type | Value                                                    | Requirement | API                                                    |
|:----------------------------------------------|:------------|:---------------------------------------------------------|:------------|:-------------------------------------------------------|
| Account: Test Account                         | Equals      | False                                                    | Required    | `AccountName__r.Test_Account__c`                       |
| Issue Type                                    | Equals      | Red, Yellow                                              | Required    | `Issue_Type__c`                                        |
| Status                                        | Equals      | Unresolved, Open - Unresolved, Open - Health Data Action | Required    | `Status__c`                                            |
| Product                                       | Equals      | *Products to include*                                    | Optional    | `Product_Family__c`                                    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*                                         | Optional    | `AccountName__r.Account_Owner_Region_CSO_Reporting__c` |

## Billable Utilization

Billable Utilization measures the proportion of contracted hours a person spends performing billable work. The definition of billable work varies between teams but is commonly used to reference activities relating to a customer as opposed to team meetings or general admin. Most teams target a billable utilization of 70% or higher.

When reporting billable utilization for an individual, the `Historical Utilization (Billable Only)` field can be used. If calculating billable utilization for a team or group, utilization will need to be calculated as the sum of `Historical Billable Hours` divided by the sum of `Historical Calendar Hours` for each group. This ensures all hours are weighted evenly and the metric is not skewed by people with differing numbers of calendar hours.

- **Object**: `Utilization Calculations`
- **Report Type**: `Utilization Calculations with U. Detail (Custom)`
- **Fields**:
  - **Individual**: `Historical Utilization (Billable Only)`
  - **Team or Group**: `Historical Billable Hours` / `Historical Calendar Hours`
- **Time Frame**: `Historical Utilization Start Date`

| Filter Field                                  | Filter Type        | Value                                   | Requirement | API                                                          |
|:----------------------------------------------|:-------------------|:----------------------------------------|:------------|:-------------------------------------------------------------|
| Historical Utilization (Billable Only)        | Greater than       | 0                                       | Required    | `pse__Historical_Utilization_Billable_Only__c`               |
| Time Period Types                             | Equals             | *Time Frame Type: Week, Month, Quarter* | Required    | `pse__Utilization_Calculation__r.pse__Time_Period_Types__c`  |
| Resource: Start Date                          | Less than or equal | Today                                   | Required    | `pse__Resource__r.pse__Start_Date__c`                        |
| Historical Utilization Start Date             | Equals             | *Time Frame Start Date*                 | Required    | `pse__Historical_Start_Date__c`                              |
| Historical Utilization End Date               | Equals             | *Time Frame End Date*                   | Optional    | `pse__Historical_End_Date__c`                                |
| Resource: Group: Group Name                   | Equals             | *Resource department*                   | Optional    | `pse__Resource__r.pse__Group__r.Name`                        |
| Resource: Salesforce User: Manager: Full name | Equals             | *Resource manager*                      | Optional    | `pse__Resource__r.ReportsTo.Name`                            |
| Resource: Full name                           | Equals             | *Resource name*                         | Optional    | `pse__Resource__r.Name`                                      |

## Issues Opened

Issues Opened measures the number of customer issues that were reported in the given time frame. Red issues are created when a customer indicates they are likely to churn, Yellow issues are created when churn is implied but not specified.

- **Object**: `Issues`
- **Report Type**: `Issues (Custom)`
- **Field**: `Record Count`
- **Time Frame**: `Date Reported`

| Filter Field                                  | Filter Type | Value                                                    | Requirement | API                                                    |
|:----------------------------------------------|:------------|:---------------------------------------------------------|:------------|:-------------------------------------------------------|
| Account: Test Account                         | Equals      | False                                                    | Required    | `AccountName__r.Test_Account__c`                       |
| Issue Type                                    | Equals      | Red, Yellow                                              | Required    | `Issue_Type__c`                                        |
| Date Reported                                 | Equals      | *Time Frame*                                             | Required    | `Date_Reported__c`                                     |
| Product                                       | Equals      | *Products to include*                                    | Optional    | `Product_Family__c`                                    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*                                         | Optional    | `AccountName__r.Account_Owner_Region_CSO_Reporting__c` |

## Issues Closed

Issues Closed measures the number of customer issues that were closed in a given time frame. This can be due to the issue being resolved, or no further action being required.

- **Object**: `Issues`
- **Report Type**: `Issues (Custom)`
- **Field**: `Record Count`
- **Time Frame**: `Date Resolved`

| Filter Field                                  | Filter Type | Value                                                                                                            | Requirement | API                                                    |
|:----------------------------------------------|:------------|:-----------------------------------------------------------------------------------------------------------------|:------------|:-------------------------------------------------------|
| Account: Test Account                         | Equals      | False                                                                                                            | Required    | `AccountName__r.Test_Account__c`                       |
| Issue Type                                    | Equals      | Red, Yellow                                                                                                      | Required    | `Issue_Type__c`                                        |
| Date Resolved                                 | Equals      | *Time Frame*                                                                                                     | Required    | `Date_Closed__c`                                       |
| Status                                        | Equals      | Resolved, Closed - Resolved, Closed - Unresolved, Closed - Health Data Action, Closed - Unresponsive Health Data | Required    | `Status__c`                                            |
| Product                                       | Equals      | *Products to include*                                                                                            | Optional    | `Product_Family__c`                                    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*                                                                                                 | Optional    | `AccountName__r.Account_Owner_Region_CSO_Reporting__c` |

## Net Promoter Score

Net Promoter Score (NPS) measures customer sentiment towards NAVEX in regards to how likely they would be to refer NAVEX to a friend or colleague. Customers are polled twice annually and provide a rating between 0 and 10; this is then used to determine an `NPS Score` of *100*, *0*, or *-100* for Promoters, Passives, and Detractors respectively. Overall score is then calculated as a **mean** average of `NPS Score`.

- **Object**: `NPS Surveys`
- **Report Type**: `NPS Survey (Custom)`
- **Field**: `NPS Score`
- **Time Frame**: `Survey Completed`

| Filter Field                                  | Filter Type | Value                 | Requirement | API                                                    |
|:----------------------------------------------|:------------|:----------------------|:------------|:-------------------------------------------------------|
| Account: Test Account                         | Equals      | False                 | Required    | `AccountName__r.Test_Account__c`                       |
| Survey Completed                              | Equals      | *Time Frame*          | Required    | `Survey_Completed__c`                                  |
| NPS - Product                                 | Equals      | *Products to include* | Optional    | `NPS_Product__c`                                       |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*      | Optional    | `AccountName__r.Account_Owner_Region_CSO_Reporting__c` |

## Upsell

Upsell measures the amount of revenue generated by the Customer Success Organization outside of the standard sales process. This is commonly through the purchase of additional software licenses and add-ons.

- **Object**: `Opportunities`
- **Report Type**: `Opp Custom`
- **Field**: `Amount (Converted)`
- **Time Frame**: `Close Date`

| Filter Field                                  | Filter Type | Value                                                                                                            | Requirement | API                                                    |
|:----------------------------------------------|:------------|:-----------------------------------------------------------------------------------------------------------------|:------------|:-------------------------------------------------------|
| Services Lead Source                          | Equals      | Up sell                                                                                                          | Required    | `Services_Lead_Source__c`                              |
| Stage                                         | Equals      | Closed Won, Booked                                                                                               | Required    | `StageName`                                            |
| Primary Campaign No Repeats)                  | Equals      | Client Care Referral, Customer Success Manager Referral, Implementation Referral, Professional Services Referral | Required    | `Primary_Campaign_No_repeats__c`                       |
| Proposed Product                              | Equals      | *Products to include*                                                                                            | Optional    | `Proposed_Product__c`                                  |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*                                                                                                 | Optional    | `AccountName__r.Account_Owner_Region_CSO_Reporting__c` |
