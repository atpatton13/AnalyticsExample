# Implementation Metrics

Implementation Services primarily operate within the `Projects` and `Milestones` objects. Projects and their associated Milestones are initially created by the Resource Management team, with `Cases` being created when work is required from other departments. Every Milestone contains a predetermined number of planned hours in which the work should be completed.

- Objects
  - [Projects](#Projects)
  - [Milestones](#Milestones)
  - [Customer Satisfaction Surveys](#Customer-Satisfaction-Surveys)
- Metrics
  - [Backlog](#Backlog)
  - [Customer Satisfaction](#Customer-Satisfaction)
  - [Customer Satisfaction Return Rate](#Customer-Satisfaction-Return-Rate)
  - [Delivery Efficiency](#Delivery-Efficiency)
  - [Hour Overages](#Hour-Overages)
  - [Hours Sold](#Hours-Sold)
  - [On-Time Completion](#On-Time-Completion)
  - [Planned Hours Completed](#Planned-Hours-Completed)
  - [Time to Implement](#Time-to-Implement)

## Objects

### Projects

Projects are used to track the Implementation effort to setup a customer on a new Product. If a customer purchases multiple Products at the same time, multiple Projects will be created, these may or may not be completed by the same Project Manager.

- **Object**: `Projects`
- **Report Type**: `Projects (Custom)`

| Filter Field                       | Filter Type | Value              | Requirement |
| :--------------------------------- | :---------- | :----------------- | :---------- |
| Account: Test Account              | Equals      | False              | Required    |
| Project: Template                  | Equals      | False              | Required    |
| Project: Group: Group Name         | Equals      | Implementation     | Required    |
| Project: Project Status            | Not Equals  | Terminated         | Required    |
| Project: Primary Product           | Not Equals  | Lockpath, WhistleB | Required    |
| Project: Exclude from PM's Metrics | Equals      | False              | Optional    |

### Milestones

Milestones are used to track individual components of a Project. Depending on the type of Project, Milestones may all be worked on by the same Implementation Manager or split between people in different departments. In some cases, Implementation Managers may work on Milestones that are connected to Professional Services Projects. These are generally included in reporting for capacity planning, but not operational metrics.

- **Object**: `Milestones`
- **Report Type**: `Projects with Milestones`

| Filter Field                       | Filter Type | Value                                 | Requirement |
| :--------------------------------- | :---------- | :------------------------------------ | :---------- |
| Account: Test Account              | Equals      | False                                 | Required    |
| Project: Template                  | Equals      | False                                 | Required    |
| Project: Group: Group Name         | Equals      | Implementation, Professional Services | Required    |
| Project: Project Status            | Not Equals  | Terminated                            | Required    |
| Project: Primary Product           | Not Equals  | Lockpath, WhistleB                    | Required    |
| Milestone: Status                  | Not Equals  | Terminated                            | Required    |
| Milestone: PM's Group              | Equals      | Implementation                        | Required    |
| Milestone: Product: Product Family | Not Equals  | Advisory Services, Code of Conduct, Expolink, Lockpath, NetClaim, WhistleB | Required |
| Project: Exclude from PM's Metrics | Equals      | False                                 | Optional    |

### Customer Satisfaction Surveys

Customer Satisfaction Surveys are sent to customers upon completion of a Project. The surveys ask several questions relating to the customer's experience with their Implementation Manager and record answers on a scale of 1 - 10.

- **Object**: `Survey Results`
- **Report Type**: `Survey (Custom)`

| Filter Field                           | Filter Type | Value              | Requirement |
| :------------------------------------- | :---------- | :----------------- | :---------- |
| Account: Test Account                  | Equals      | False              | Required    |
| Project: Template                      | Equals      | False              | Required    |
| Project: Group: Group Name             | Equals      | Implementation     | Required    |
| Project: Project Status                | Not Equals  | Terminated         | Required    |
| Project: Primary Product               | Not Equals  | Lockpath, WhistleB | Required    |
| Survey Results: Imp Comp q3            | Not Equals  | ""                 | Required    |
| Survey Results: Exclude from Reporting | Equals      | False              | Required    |
| Project: Exclude from PM's Metrics     | Equals      | False              | Optional    |

## Metrics

### Backlog

Backlog tracks the number of Planned Hours remaining on open Milestones. If more hours are submitted against a Milestone than are planned, the additional hours do not count towards backlog reduction.

- **Object**: `Milestones`
- **Report Type**: `Projects with Milestones`
- **Field**: `Milestone: Planned vs. Client Billable (no neg)`

| Filter Field                                  | Filter Type | Value                                 | Requirement |
| :-------------------------------------------- | :---------- | :------------------------------------ | :---------- |
| Account: Test Account                         | Equals      | False                                 | Required    |
| Project: Template                             | Equals      | False                                 | Required    |
| Project: Group: Group Name                    | Equals      | Implementation, Professional Services | Required    |
| Project: Project Status                       | Not Equals  | Terminated                            | Required    |
| Project: Primary Product                      | Not Equals  | Lockpath, WhistleB                    | Required    |
| Milestone: Status                             | Not Equals  | Terminated                            | Required    |
| Milestone: Product: GL Group                  | Equals      | Required Setup, Other Services        | Required    |
| Milestone: Product: Product Family            | Not Equals  | Advisory Services, Code of Conduct, Expolink, Lockpath, NetClaim, WhistleB | Required |
| Milestone Status                              | Not Equals  | Complete, Terminated                  | Required    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*                      | Optional    |

### Customer Satisfaction

Customer Satisfaction (CSAT) measures the average score of returned Surveys.

- **Object**: `Survey Results`
- **Report Type**: `Survey (Custom)`
- **Fields**: `Survey Results: Imp Comp q3`
- **Time Frame**: `Survey Results: Survey Completed`

| Filter Field                                  | Filter Type | Value                     | Requirement |
| :-------------------------------------------- | :---------- | :------------------------ | :---------- |
| Account: Test Account                         | Equals      | False                     | Required    |
| Project: Template                             | Equals      | False                     | Required    |
| Project: Group: Group Name                    | Equals      | Implementation            | Required    |
| Project: Project Status                       | Not Equals  | Terminated                | Required    |
| Project: Primary Product                      | Not Equals  | Lockpath, WhistleB        | Required    |
| Survey Results: Imp Comp q3                   | Not Equals  | ""                        | Required    |
| Survey Results: Exclude from Reporting        | Equals      | False                     | Required    |
| Survey Results: Delivery Survey Type          | Equals      | Implementation Completion | Required    |
| Project: Exclude from PM's Metrics            | Equals      | False                     | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*          | Optional    |

### Customer Satisfaction Return Rate

Customer Satisfaction (CSAT) Return Rate measures the percentage of Customer Satisfaction Surveys that were returned against the total number sent.

- **Object**: `Projects`
- **Report Type**: `Projects (Custom)`
- **Fields**: `Project: # of Surveys Completed` / `Project: # of Surveys Sent`
- **Time Frame**: `Project: End Date`

| Filter Field                                  | Filter Type | Value              | Requirement |
| :-------------------------------------------- | :---------- | :----------------- | :---------- |
| Account: Test Account                         | Equals      | False              | Required    |
| Project: Template                             | Equals      | False              | Required    |
| Project: Group: Group Name                    | Equals      | Implementation     | Required    |
| Project: Project Status                       | Not Equals  | Complete           | Required    |
| Project: Primary Product                      | Not Equals  | Lockpath, WhistleB | Required    |
| Project: Exclude from PM's Metrics            | Equals      | False              | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*   | Optional    |

### Delivery Efficiency

Delivery Efficiency measures the proportion of hours worked on Project Milestones against those planned. A value greater than 100% means the Milestone was completed in fewer hours that expected.

- **Object**: `Milestones`
- **Report Type**: `Projects with Milestones`
- **Fields**: `Milestone: Planned Hours` / `Milestone: Total Approved Hours`
- **Time Frame**: `Milestone: Actual Go Live`

| Filter Field                                  | Filter Type | Value              | Requirement |
| :-------------------------------------------- | :---------- | :----------------- | :---------- |
| Account: Test Account                         | Equals      | False              | Required    |
| Project: Template                             | Equals      | False              | Required    |
| Project: Group: Group Name                    | Equals      | Implementation     | Required    |
| Project: Project Status                       | Not Equals  | Terminated         | Required    |
| Project: Primary Product                      | Not Equals  | Lockpath, WhistleB | Required    |
| Milestone: Status                             | Not Equals  | Complete           | Required    |
| Milestone: PM's Group                         | Equals      | Implementation     | Required    |
| Milestone: Product: Product Family            | Not Equals  | Advisory Services, Code of Conduct, Expolink, Lockpath, NetClaim, WhistleB | Required |
| Project: Exclude from PM's Metrics            | Equals      | False              | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*   | Optional    |

### Hour Overages

Hour Overages measure the number of hours that were work in addition to those planned.

- **Object**: `Milestones`
- **Report Type**: `Projects with Milestones`
- **Field**: `Planned Hour Overages (Last Month)`
- **Time Frame**: The `Milestone` object contains several *Last Month* fields that show the relevant hours for the previous month. For historical data the `Milestone Monthly Hours` object should be used.

| Filter Field                       | Filter Type  | Value                                 | Requirement |
| :--------------------------------- | :----------- | :------------------------------------ | :---------- |
| Account: Test Account              | Equals       | False                                 | Required    |
| Project: Template                  | Equals       | False                                 | Required    |
| Project: Group: Group Name         | Equals       | Implementation, Professional Services | Required    |
| Project: Project Status            | Not Equals   | Terminated                            | Required    |
| Project: Primary Product           | Not Equals   | Lockpath, WhistleB                    | Required    |
| Milestone: Status                  | Not Equals   | Terminated                            | Required    |
| Milestone: Product: GL Group       | Equals       | Required Setup, Other Services        | Required    |
| Milestone: Product: Product Family | Not Equals   | Advisory Services, Code of Conduct, Expolink, Lockpath, NetClaim, WhistleB | Required |
| Planned Hour Overages (Last Month) | Greater Than | 0                                     | Required    |
| Project: Exclude from PM's Metrics | Equals       | False                                 | Optional    |

### Hours Sold

Hours Sold measures the number of Planned Hours of work that have been generated from booked sales Opportunities. These hours are added to the Backlog.

- **Object**: `Milestones`
- **Report Type**: `Projects with Milestones`
- **Field**: `Milestone: Total Planned Hours`
- **Time Frame**: `Project: Opportunity: Close Date`

| Filter Field                       | Filter Type | Value                                 | Requirement |
| :--------------------------------- | :---------- | :------------------------------------ | :---------- |
| Account: Test Account              | Equals      | False                                 | Required    |
| Project: Template                  | Equals      | False                                 | Required    |
| Project: Group: Group Name         | Equals      | Implementation, Professional Services | Required    |
| Project: Project Status            | Not Equals  | Terminated                            | Required    |
| Project: Primary Product           | Not Equals  | Lockpath, WhistleB                    | Required    |
| Milestone: Status                  | Not Equals  | Terminated                            | Required    |
| Milestone: Product: GL Group       | Equals      | Required Setup, Other Services        | Required    |
| Milestone: Product: Product Family | Not Equals  | Advisory Services, Code of Conduct, Expolink, Lockpath, NetClaim, WhistleB | Required |
| Project: Exclude from PM's Metrics | Equals      | False                                 | Optional    |

**Note:** `Course Swap` Milestones track work updating Online Training configurations. They are not connected to an Opportunity and carry *Planned Hours* but no *Revenue*. These can be included in Hours Sold reporting by including `Milestone: Created Date` equals *Time Frame* and `Milestone Name` contains *Course Swap*.

### On-Time Completion

On-Time Completion measures the proportion of Project Milestones that are completed on or before the due date.

- **Object**: `Milestones`
- **Report Type**: `Projects with Milestones`
- **Field**: `Milestone: Milestone On Time TD`
- **Time Frame**: `Milestone: Actual Go Live`

| Filter Field                                  | Filter Type | Value                                 | Requirement |
| :-------------------------------------------- | :---------- | :------------------------------------ | :---------- |
| Account: Test Account                         | Equals      | False                                 | Required    |
| Project: Template                             | Equals      | False                                 | Required    |
| Project: Group: Group Name                    | Equals      | Implementation                        | Required    |
| Project: Project Status                       | Not Equals  | Terminated                            | Required    |
| Project: Primary Product                      | Not Equals  | Lockpath, WhistleB                    | Required    |
| Milestone: Status                             | Not Equals  | Complete                              | Required    |
| Milestone: PM's Group                         | Equals      | Implementation                        | Required    |
| Milestone: Product: Product Family            | Not Equals  | Advisory Services, Code of Conduct, Expolink, Lockpath, NetClaim, WhistleB | Required |
| Project: Exclude from PM's Metrics            | Equals      | False                                 | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*                      | Optional    |

### Planned Hours Completed

Planned Hours Completed measures the number of hours that were removed from the backlog. If more than the Planned Hours are submitted against a Milestone, they do not contribute to backlog reduction. If a Milestone is Completed in under the Planned Hours, all Planned Hours are recognized.

- **Object**: `Milestones`
- **Report Type**: `Projects with Milestones`
- **Field**: `Milestone: Planned vs Billable Hours (Last Month)` + `Milestone: Under Planned Hours (Last Month)`
- **Time Frame**: The `Milestone` object contains several *Last Month* fields that show the relevant hours for the previous month. For historical data the `Milestone Monthly Hours` object should be used.

| Filter Field                       | Filter Type | Value                                 | Requirement |
| :--------------------------------- | :---------- | :------------------------------------ | :---------- |
| Account: Test Account              | Equals      | False                                 | Required    |
| Project: Template                  | Equals      | False                                 | Required    |
| Project: Group: Group Name         | Equals      | Implementation, Professional Services | Required    |
| Project: Project Status            | Not Equals  | Terminated                            | Required    |
| Project: Primary Product           | Not Equals  | Lockpath, WhistleB                    | Required    |
| Milestone: Status                  | Not Equals  | Terminated                            | Required    |
| Milestone: Product: GL Group       | Equals      | Required Setup, Other Services        | Required    |
| Milestone: Product: Product Family | Not Equals  | Advisory Services, Code of Conduct, Expolink, Lockpath, NetClaim, WhistleB | Required |
| Planned vs Billable Hours (Last Month)<br />&emsp;*or* Under Planned Hours (Last Month)  | Greater Than | 0 | Required |
| Project: Exclude from PM's Metrics | Equals      | False                                 | Optional    |

### Time to Implement

Time to Implement measures the average time it takes for Project Milestones to be completed.

- **Object**: `Milestones`
- **Report Type**: `Projects with Milestones`
- **Field**: `Milestone: Calculated Duration (days)`
- **Time Frame**: `Milestone: Actual Go Live`

| Filter Field                                  | Filter Type | Value                                 | Requirement |
| :-------------------------------------------- | :---------- | :------------------------------------ | :---------- |
| Account: Test Account                         | Equals      | False                                 | Required    |
| Project: Template                             | Equals      | False                                 | Required    |
| Project: Group: Group Name                    | Equals      | Implementation                        | Required    |
| Project: Project Status                       | Not Equals  | Terminated                            | Required    |
| Project: Primary Product                      | Not Equals  | Lockpath, WhistleB                    | Required    |
| Milestone: Status                             | Not Equals  | Complete                              | Required    |
| Milestone: PM's Group                         | Equals      | Implementation                        | Required    |
| Milestone: Product: Product Family            | Not Equals  | Advisory Services, Code of Conduct, Expolink, Lockpath, NetClaim, WhistleB | Required |
| Project: Exclude from PM's Metrics            | Equals      | False                                 | Optional    |
| Account: Account Owner Region (CSO Reporting) | Equals      | *Account region*                      | Optional    |
