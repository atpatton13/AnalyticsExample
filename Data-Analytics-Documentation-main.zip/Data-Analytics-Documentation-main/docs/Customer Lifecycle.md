# Customer Lifecycle

Location: [Customer Lifecycle](https://navex-my.sharepoint.com/:x:/g/personal/connor_belvin_navexglobal_com/Eb4G7hi0GpZAq9a_-FLj-N8BuFJz_9Ph123-g8JoSQQF-w?e=UsI624)

Cadence: **Weekly** and **Monthly**

Due Date: **Mondays** and **First Working Day** of the month

## Introduction

The Customer Lifecycle document and [PowerPoint](https://navex-my.sharepoint.com/:p:/g/personal/aaab_navexglobal_com/EWCXNmTKAcxBtHttzilFg_sBXdDEGlfV4tf-CO3txYWqug?e=YxoLqR) that is linked are brought together to track the progression of customers in their attempt to resolve issues they are facing. Customers can go multiple routes when trying to resolve issues, but the goal is to have them follow a specific series of events. 

## Goals of Reporting

Ultimately want to see customers go from using our NAVEX help pages to Skilljar and if they have not been able to self diagnose and resolve the issue from these resources, they will then create a case. Once this case is opened, either by phone or by email, the data created is tracked in this report to know how teams are handling the cases, which companies submit more cases, and if Skilljar is being used more frequently or not.

## Power Query

The overall query needs some attention due to the length of time it takes to run a couple of pieces.

1. There are two ICBM queries that pull data from a specific folder that the Monthly and Weekly data is deposited in manually (Aaron Aab has access to the root folder for all queries)
    1. This link was used to guide the process for the ICBM queries:
        1. [Excel's Merging of Files](https://exceloffthegrid.com/power-query-import-all-files-in-a-folder/)
    2. Thess initial queries are setup from Excels process of cleaning and merging multiple files in a folder
    3. Each Monday, and the first of the month, the CSO email will receive a new data set with its respective name (Weekly or Monthly)
    4. The last query on the list within excel is also in charge of compiling this information into something that is more legible (ICBM Final Prep)
        1. This breaks down the data into Monthly and Weekly
    5. If access to ICBM is needed to create more pulls of the phone center data, connect with Beth kelley to get this setup
        1. Report Schedule will also be needed
    6. An item to address: When running the PQ the files will need to be in a folder that is not accessed via any sort of login (PQ currently has issues with SharePoint since it is password protected). Therefore, the files will need to be stored on someone’s PC (and backed up on OneDrive). Once the files have been moved, the PQ path will need to be changed to reflect this as well
        1. This can be accomplished by moving the files to the :S drive
        2. To connect to :S drive, login to the VPN
2. The Second Query on the list is referring to the Skilljar data
    1. This is coming from the Salesforce objects Accounts, Contacts, Courses, and Skilljar data to bring in relevant information
    2. Matt Thorne, Samantha Vandehey and one other have been removed from the dataset because they were in charge of creating it, so they had many test accounts/courses
3. Case Submission and Routing - This is regarding the initial input received from customers and where the case is sent thereafter
    1. There is a formula that calculates the cost of a case (currently it is $68 per hour) in the subsequent data table
    2. Visualizations count the number of cases submitted by Customers
    3. This is broken down into the cases submitted within the last 5 weeks, and cases submitted over the last 12 months
        1. These are also broken down into only open cases or all cases

## Data Tables

There are multiple tables for the cases data, but this is because it is broken down into Weekly and Monthly and whether or not those are only Open Cases.
