# Crosswalk workbook and cleaner script for Benchmark Data

In order to display benchmark data via Shiny Dashboard, a csv with correct data in the 32 matching columns must be prepared from raw data collected from EthicsPoint, AlertLine, ExpoLink or WhistleB servers.

These 32 fields and their data types are as follows:

<pre>
EPCaseId                          object
Followups                          int64
ReportDate                datetime64[ns]
Case_DateClosed           datetime64[ns]
ClientId                           int32
ClientName                        object
Employees                          int64
Case_CompanyCity                  object
Case_CompanyState                 object
PostalCode                        object
Case_CompanyCountry               object
CallerPosition                    object
Case_ReporterAnonymous            object
FirstTimeCaller                  float64
CaseType                          object
IntakeMethod                      object
HowLearned                        object
Language                          object
ManagementInvolved                 int64
PrimaryAllegDesc                  object
IssueType                         object
PrimaryAllegPriority              object
DateAllegedIncident       datetime64[ns]
SecondaryAllegDesc                object
SecondaryAllegClass               object
SecondaryAllegPriority            object
ActionTaken                       object
Outcome                           object
ReportYear                         int64
ClosedYear                         int64
ReporterViews                     object
ReporterFollowUps                 object
Database                          object
</pre>

## Set up Directory

To begin, move the Closed and Open csv files you'd like to clean into a folder on your computer with the latest version of the Crosswalk csv file pulled from the [CSO Data Analytics Sharepoint](https://navex.sharepoint.com/sites/DataAnalystTeam/Shared%20Documents/Forms/AllItems.aspx).

Download [`requirements.txt`](https://navex.sharepoint.com/:t:/s/DataAnalystTeam/EUarl2jfmANIpOQ1U3O_vjABWVHkBI0bgmNBVJOCHHHi-g?e=U5JLNo) and move it into the same folder. Open the command line terminal, change your current directory to the location of this file (*`cd 'Users\your.name\Documents\csv_cleaner'`*), copy and paste the following text `pip install -r requirements.txt` then hit enter.

## Clean the raw data

After the packages have loaded, type `spyder` into the command line and hit enter again. *Make sure none of the files you will be cleaning are open in Excel before you begin.*

Using Spyder, open [`csv_cleaner.py`](https://navex.sharepoint.com/:u:/s/DataAnalystTeam/Ear0eMLGCFFFsS8cTw99hMwBmhnp6_PPxjCsWEscUKFKwg?e=vnGSgx) and hit the triangle 'play' button to begin the series of prompts in Spyder's console.

## Update the Crosswalk

Several output files will appear in the folder on your computer you have designated, the ones beginning with the two-letter identifier of their associated product are the cleaned output files while the others list exception values which could not be mapped to the cleaned output xlsx and csv files. In order to map these exception values in the Crosswalk, you will need to manually add them to the sheet within the Crosswalk workbook which shares the name of the exception file. Some values cannot be mapped and are listed here:
<pre>
IntakeMethod        0, 111, 602
IssueType           0
Country_Aliases     0, &ltNone&gt
Outcome             0
Salesforce          0
</pre>

Select 'Save as..." from the file menu after updating your Crosswalk file and add a number the name to make the latest version unique.

Repeat this process once more, this time choosing the updated Crosswalk workbook when prompted in the Spyder console.

## Manually map remaining exceptions

Open the output xlsx file in Excel. You will notice the output file has 37 columns, five of which have "DELETE" appended to the column headers. The information in these columns will help you assign appropriate values to the rows filled with "FEEDBACK NEEDED". Select the entire sheet by clicking the top left corner and apply a Filter.

Search for "FEEDBACK NEEDED" and choose a column that contains this value to filter and view only these values in the results. Among the other values in that column, you will be replacing "FEEDBACK NEEDED" with the one that best suits the case. Reference values in the DELETE columns and apply filters on other columns as needed to quickly replace every "FEEDBACK NEEDED" with the appropriate values.

After replacing all of these values with valid designations, delete the five columns with "DELETE" in the title and save the file.
