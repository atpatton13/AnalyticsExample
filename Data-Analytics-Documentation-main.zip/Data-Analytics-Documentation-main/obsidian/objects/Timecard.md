[[Implementation]] and [[Professional Services]] use Projects, Project Tasks, Project Milestones, and Milestone Task Time.

Cases also have Case Milestones and Task Time.

The two combined make Timecards. Some data is lost between cases/projects to timecards in the process.