API Name / Object Variable for [[App Config]] which is the Label.

- Gateway__c field refers to 'On/Off Platform' via 'Yes/No' picklist.

NAVEX Hosted could be NAVEX LMS Hosted OR NAVEX One Hosted 