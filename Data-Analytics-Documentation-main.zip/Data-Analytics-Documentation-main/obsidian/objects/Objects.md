#todo 
In programmatic language, an [[Object]] takes a specific data template - called a #class - and creates an instance of it. 

In Salesforce, however, [[Objects]] are [[database]] tables, and each field in an object is analogous to a table column. These 'objects' are therefore #relational tables as you might find in a typical [[relational database]].
### Frequent and Common SF Objects in Reporting:
1) [[Account]]
2) [[Asset]] - any product line, may include subscription
3) [[App Config]] - active asset implementation
4) [[Case]]
5) [[Contact]]
6) [[Contract]]
7) [[Gainsight]] - Health Score
8) [[Industry]]
9) [[Opportunity]]
10) [[Product]]
11) [[Project]]
12) [[Survey]]
13) [[User]] - Salesforce User, i.e., user account and related data

Object #relational #diagram - most frequent objects utilized or otherwise referenced in reports
![[NAVEX SF Object Diagram.png]]

### #salesforce/tips  
- If you come across a #field you don't recognize, in the search bar when you've navigated to Setup, it will give you the option to search field names in object manager. 
- The object manager is also where further details pertaining to objects can be viewed - note that Field Names (variable names) are often different than the Field Labels (which show up in [[Salesforce Lightning]] [[Report]]s)
- Every object's primary key in the API is called "Id".