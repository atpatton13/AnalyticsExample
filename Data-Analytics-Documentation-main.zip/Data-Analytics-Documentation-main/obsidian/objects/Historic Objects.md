#object 
Accessed by `Histories` in SOQL.


- Last Login Date in IRM (on Platform Config)
- Pendo API Query (Both EPIM and NE)
- Screening Usage (RR)