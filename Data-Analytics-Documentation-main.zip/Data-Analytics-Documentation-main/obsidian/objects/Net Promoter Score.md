#object 
One record per super product family on an [[Account]].