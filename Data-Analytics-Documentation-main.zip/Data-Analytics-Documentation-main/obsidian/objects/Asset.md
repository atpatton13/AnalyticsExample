A [[NAVEX]] asset is generally any product line on a recurring schedule. A single asset is a discrete service or subscription sold.
As of 2/26/24, assets are being duplicated for bundles. Need to filter for Split Parent Asset = False to remove the bundle.

### #field Values and Labels
- [[Product Family]]
- Status
- Asset Dates
- [[ARR]] (converted)
- Individual name of asset
- Renewal Date
- Quantity = License_Metric_Quantity__c
When an asset is sold, its status becomes 'pre-maintenance'.
Recurring product = "Net ARR != 0"
- Asset is already converted ARR in Salesforce
- Through Platform Config can access 'Hosting Method' (Customer Hosted, NAVEX Hosted)
FILTER SPLIT PARENT ASSET OUT FOR ARR (Split Parent Asset == False)
### Queries
- Status = Pre-Maintenance, On Maintenance, Off Maintenance, or simply 'contains maintenance'
	- Including Status = 'Not Renewing' will include more assets but represent less ARR per record because ARR becomes 0 once slated for decom.
### Relationships
[[App Config]], [[Account]], [[Asset History]], [[Product]], [[Contract]]

