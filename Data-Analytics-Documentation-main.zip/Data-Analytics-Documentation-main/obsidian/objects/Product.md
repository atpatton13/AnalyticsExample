[[NAVEX]] #object #todo
`Product2` is the API name of the Product object that contains a list of all available items for sale.
- Single-line products which belong to a [[Product Family]].
- sometimes referred to as SKU or SKUs (accessed by Product Code label)
- For an [[Asset]] to become a product, the related [[Opportunity]] has to be Closed.
- 'Product Code' is the SKU related to the asset.
- Not all Product records in the primary quote of the booked opp will become Assets - only if they are Assetizable.



- Exclude Assetizable Products tha`t end in 'MIG SVC' since they're not a subscription asset.

- Use Opportunities with Products when reporting on specific products to show grouped products under the same opportunity -> subtotal of 'Total Price' on each opp will reflect the ARR. 
### #field Labels and Values
### Relationships and Automations
A [[CPQ Quote]] contains Quote Products which relate to some Product2 record and they all ultimately become an [[Asset]] if they are related to a [[Primary Quote]], the associated [[Opportunity]] changes from Stage to Booked, and the Product record it relates to has `Assetizable = TRUE`. The Product record name becomes the Asset Name. 