#object 
Simple calculation of [[Billable Hours]] / (Calendar Hours - Time Off(PTO))].
Historical reporting up to 4+ years. 
Fields are rollups.
Can't always be filtered properly -- Moving from one team to another would have all their utilization records listed under their current team. Therefore historical group is referenced under [[Historical Utilization]].

Typically, 6-month onboarding period for new hires and a 3-month onboarding period for employees who switch departments

- Calculations are run every Monday around 12:00 PM PST, once Time Compliance emails have been sent out.