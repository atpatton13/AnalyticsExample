#object 
Historic reporting for [[App Config]]. Has fields related to counts of reports as below.

- History_Date__c (LTM = 'Last Twelve Months', most used date range)

### #field Values
EP Report Counts:
	- "Phone" = EP_Count_Phone_Cases__c
	- "Web" = EP_Count_NonPhone_Dispatched
	- "Other" = EP_Count_NonPhone_NotDispatched

