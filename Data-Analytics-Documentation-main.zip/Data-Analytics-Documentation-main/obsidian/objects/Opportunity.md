#todo 
#object Notes about implementation, 'lockdown' object which can only be edited by record creator.

Opportunities can have multiple projects, as different products have different implementations. Some may require PS, some are implementation

"Needs Analysis" = 50% Probability = Sales Qualified Lead

Opportunity Records have 'Owners', a [[User]] related record - use 'Created By' instead of 'Opp Referred By' if you have a problem, take it up with Dan Buckwell lol!

Created on an Asset, and new opportunities can no longer be created on an asset once it's decommissioned.

Renewal Opps only exist if a customer has already been booked for a product.

[[Asset]]s are typically more accurate to report on but sometimes information is added incorrectly - whenever an asset changes, there should be an opportunity for it.
- Each opp should be tied to the asset changed/created by the opp.

[[Contract]]s are based on booked opportunities, therefore the opportunity can be more of a source of truth about what the asset should be saying

Opportunity is good for tracking [[Migration]] as 'Data Center Location' typically has more accuracy than App Config's 'Data Hosted In' where possible
### #field Labels and Values
- 'Order Type': picklist containing [[Migration]].
- 'Order Sub-type': "Full Decommission" = All OLIs related to the Opportunity are decommissioned, otherwise "Partial Decommission" for one or more OLIs.
- 'Record Type' (Opp_Record_Type_Text_Field__c): Standard_New, Annual_Add_On, Renewal, Decommission. When 'Renewal', should match Asset Renewal Term Dates
- 'IsWon'
- 'Funnel Source' - based on creator of the opp, looks at where User was in sales cycle of Renewal opps. ('Opportunity Referred By' is causing too many problems, use 'Created By' instead!!)
- 'Total Price' - summed across the opp will show the ARR.
- 'Type' = 'New Business' - net new customer with no active subscription 
	- = 'Existing Business' - customer which has ANY active subscription.
### Relationships
[[Opportunity Product]], [[CPQ Quote]], [[Project]] (1:M), 
