#todo #object
- Each Account in Salesforce ties to a specific customer of NAVEX, be it past, present, or prospective. 
### #field Values and Labels
- Types: Prospects, Customer, Former Customer, Partner (under Type #field)
- [[Contact]] records relate to a single Account record through the Account #field
- However, each Account typically has multiple [[Contact]]s
- Sales_rep_role__c = AE Segment (Small - medium - large company indicator)
- CSM Segment (Level of CSO Interaction: \[Tech, Low, Medium, High, Executive]-touch)
- Reporting Region (North America <-> International)
- [[Account Contact Role]] records connect to a single Account and a single Contact
- Group support: 'HAS Group Support \[EP, NE, PT]' field label
- Currency ISO Code
- [[Churn and Churn Rate]] - Account Type = "Former customer" for churned accounts
- Service provided in -> __NECESSARY__ field
- Core Territory Type - contains values like 'Farmer', typically paired with Account Sales Rep Role
- Active_Super_Product_Families__c - looks across all related Assets and uniquely represents every SPF present across Assets with Active = TRUE
- Apps_on_Platform_Auth__c  - looks across all App Configs and uniquely represents every App Name present across App Configs where On Platform = Yes
- Industry (standard field) is actively audited and most accurate source of truth for account information.
### Relationships
[[App Config]], [[Case]], [[Issue]], [[Lead]], [[Opportunity]], [[Product]], [[User]] 

### #salesforce/tips 
- Never use Parent Account. Hierarchical relationships are completely wrong if not inconsistent. It's a Sales object (dept. not rigorous about keeping it maintained)

