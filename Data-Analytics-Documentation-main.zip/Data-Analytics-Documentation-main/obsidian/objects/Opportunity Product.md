Intermediary #object between [[Opportunity]] and [[Asset]] which has the API name [[OpportunityLineItem]]. Not all Opp product records relate to an asset, however.

Case field - 'Related Opportunity' can merge on Opp Product 'Opportunity ID' to find opportunity Total Price by account (can be related to churn when Case record type = Discontinued Client and Date of Data Request is specified to specific churn month)
ACV List Value = sum of the List Price of the Opportunity Line Items

There is no 'child opp' for the rollups

### #field 
- `TotalPrice` - Amount of ARR churn for OLIs with related assets. 