#todo #object 

Has a dataset in [[CRMA]].

 - [[Case JIRA Ticket]] - In-between object with Cases

### Notable Fields:
Id, OwnerId, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById, Account__c, Case__c, Country__c, Description__c, Due_Date__c, JIRA_Assignee__c (**username**), JIRA_Close_Date__c, JIRA_Issue_Type__c, JIRA_Project__c (**Ticket type**), JIRA_Status__c, Product_Family__c, Summary__c, Account_Name__c, Owner_Name__c, Customer_Temperature__c

'Product Family' Label -> looks at the App Config name.