#todo #object 
Typically when referring to Customer Support, only relates to [[Case Milestones]] which fall under Customer Support management reports (CSMs looking at CST milestone metrics.)

Go-Live Revenue is reported on in Milestones.

"Closed Date" Milestones are typically referenced by Actual Go Live as the date field to check for close date in PS/IS.

[[Project]]s also have milestones (1:M) and BOTH have a kickoff date field in reporting.

pse__Milestone__c is the API name.

Any 'Setup' milestone is an indication of a change in service -> increased risk for [[Churn and Churn Rate]].