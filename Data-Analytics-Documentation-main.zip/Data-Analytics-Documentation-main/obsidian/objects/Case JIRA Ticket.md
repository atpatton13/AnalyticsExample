#todo #object 

[[Case]] and [[JIRA Ticket]] in-between object.

### #field Values and Labels
Id, OwnerId, CurrencyISOCode, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById,
JIRA_Ticket__c, Case__c, Account__c (NAME) , Case_Owner__c (NAME), Case_Status__c, Case_Subject__c, JIRA_Status__c, Summary__c, 