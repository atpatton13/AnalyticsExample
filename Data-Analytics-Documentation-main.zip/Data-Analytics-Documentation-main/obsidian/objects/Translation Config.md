#object 
Like [[Course Config]]s, has course and translation information on it like delivery date.