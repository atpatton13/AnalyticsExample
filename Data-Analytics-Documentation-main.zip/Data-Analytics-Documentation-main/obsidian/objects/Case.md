#todo #object 
### Relationships
[[Milestone]], [[Project]] (M:1), [[Survey]], [[User]] (i.e., Case Owner)

Cases don't usually relate to product - bucket by Client_Care_Team__c
<u>Web Services Support</u> Cases relate to specific Skill: EthicsPoint - Web Services API
Connected Milestones are Case Milestones also for [[Timecard]] purposes.
### Case Record Types (API: Record_Type__c)
- Customer Support Requests
- Discontinued Client (Sometimes referred to as decommission cases)

### #field Values
Id, ContactId, AccountId, Status, Subject, Priority, Description, ClosedDate, OwnerId, CreatedDate, CreatedById, LastModifiedDate, LastModifiedById, Due_Date__c, X18_Digit_AccountId__c, Record_Type__c, Account_Name__c, Owner__c,