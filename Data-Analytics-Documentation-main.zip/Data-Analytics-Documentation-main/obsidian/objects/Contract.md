#todo #object 
Does not always relate well to Asset in terms of dates.

Notable fields: Renewal_Date