An Application Configuration is an implementation of a particular product.
[[Super Product Family]] as an object!
Configuration info for implementation of a product. [[New App Config]] script can make new configurations in R as requested by management or CSO.
- As of 2024-07-26, Account_Name__c is an inconsistent field - many nulls or 'Related Account' IDs
- While the field label is generally labeled as Application Config in object managers, the API name to access the variable is actually called [[Platform Configuration]], with the related object denoted as Platform_Configuration__c
- EthicsPoint App Configs come with an EP Client ID unique to each account.
- Count: Over 15,000 app config records!
- _EPIM Customer Report_ counts can be accessed through Platform Config w/ Platform Config History Weekly.
- Best field for EP_Client_ID (EP Client ID), historically EP_Client_ID__c from Cases__c


### Queries
- Products on/off Platform: Gateway__c field
	- NAVEX Hosted / Customer Hosted not on Platform
- Name != Alertline, Compliance Manager, Integrilink, Expolink, Suite, others
- Active = True

### Relationships
[[Account]](M:1), [[Asset]] (each asset tied directly to one app config), [[Course Config]] 

- App Config is a rollup of the assets.
- Some orgs have multiple app configs for different assets.


### Hosting Meanings for NAVEXEngage
#### _Customer Hosted_
Product: “includes NavexEngage”  
Apps on Platform: NAVEXEngage  
Client Hosted Training: True  
  
#### _NAVEX Hosted_ 
Product: “includes NavexEngage”  
Apps on Platform: Need more info
Client Hosted Training: False  
  
#### _NAVEX One_  
Product: “includes NavexEngage”  
Apps on Platform: NAVEXEngage  
Client Hosted Training: False