Access history of [[Asset]] records (API Label: Asset__History__c, not Asset__History).

Has more specificity as an additional kind of History which doesn't apply to most other [[Historic Objects]].