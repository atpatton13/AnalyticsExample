#object 
Important regarding employee records and [[User]] (Time Compliance as well): make sure new or transferred employees have the correct Group and Role when assigned/reassigned.

Contact records are how permissions are delegated by Business Systems within Salesforce. Contact records need to be created in order for individuals to be able to view dashboards within Salesforce.

When dealing with alert flag customer contacts, for contacts with flags of either US or EU, remember to filter out Email_Opt_Out_Service_Notifications__c = TRUE.

'Resource' is a Contact-related record. 'Group' is also a Contact-related record

[[Account Contact Role]] can relate to multiple Accounts for a single Contact record.