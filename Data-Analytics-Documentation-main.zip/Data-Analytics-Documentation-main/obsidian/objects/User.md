#todo  #object
- Can be referenced in the Owner field of an Account Record
Sales_Rep_Role__c -> AE Segment
Opportunity: Market Segment at Close -> AE Segment _at time off opp close_
### #salesforce/tips 
- Use User record: Full Name instead of [[Contact]] Record: Full name (which is sanitized)
- Community-relevant data is stored in User Type and related [[Profile]] field: Name