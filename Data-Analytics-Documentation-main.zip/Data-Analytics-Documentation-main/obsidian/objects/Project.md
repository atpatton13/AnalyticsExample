#object 
- Typical label: PSE Project
- Value: pse__Proj__c

PSE Projects are related to projects, not cases. [[PSE Milestone]]s are thus project milestones whereas [[Milestone]]s are more reported in Customer Support and related to [[Case]].
**[[Implementation]] Services uses Project most frequently**.
Each project should have one opportunity.

Contains Billable Utilization resource.
Project Managers = Resource = [[Contact]] records.
### Fields
- Project Status - pse__Project_Status__c
- Type - pse__Project_Type__c
### Relationships
[[Case]]s (1:M), [[Contact]]s, [[Opportunity]] (M:1)
