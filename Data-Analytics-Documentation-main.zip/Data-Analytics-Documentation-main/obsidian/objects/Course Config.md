#todo #object 
For [[Compliance Training]], each [[Platform Configuration]] has Course Configs (API Label is Platform_Course_Configuration__c) which then have [[Translation Config]]s.

Aggregates up to the [[App Config]].

Contain Course information like Delivery Date, Language, Training Course Name.

Example Record - [Workplace Harassment 10 ADAPT-C | Application Course Configuration | Salesforce](https://navex.lightning.force.com/lightning/r/Platform_Course_Configuration__c/aEWHs000000PHJvOAO/view)
Example Report - [NE Oracle LMS Customers | Salesforce](https://navex.lightning.force.com/lightning/r/Report/00OHs000009sQRcMAM/view)

As of 2/28/24, Current CCA Pipeline could use 

If a customer has a 1-course subscription, they can swap out once a year. They don't necessarily have to archive an old course before obtaining a new course. (BURST CAN HAVE UP TO 6 PER SINGLE COURSE)

### "Version Number Discussion" Meetings
- #meeting As of 2024-03-21 a 'primary' flag field for what course is most up-to-date is being developed with Product/Product Development/Management
- ultimately want to show current version against customer's version

- #meeting 2024-03-28
	- Version data relevant to courses and languages already present in Snowflake S3 has the data 