suppressPackageStartupMessages({
  library(tidyverse)
  library(salesforcer)
  library(openxlsx)
  library(knitr)
})

# Import config file
config <- yaml::read_yaml("config.yml")

# Get Salesforce OAuth connection
sf_auth()

# Query Salesforce for Account info ----
Accounts_all <- sf_query("SELECT Platform_Configuration__r.Id,
                            Platform_Configuration__r.Name,
                            Platform_Configuration__r.Gateway__c,
                            Platform_Configuration__r.Platform_Date__c,
                            Platform_Configuration__r.Platform_Migration_Status__c,
                            Platform_Configuration__r.Delivery_Platform__c,
                            Platform_Configuration__r.Hosting_Method_NE__c,
                            Platform_Configuration__r.Platform_Key__c,
                            Platform_Configuration__r.Insights__c,
                            Platform_Configuration__r.Languages_Non_English_NE__c,
                            Platform_Configuration__r.Incompatible_Courses_NE__c,
                            Platform_Configuration__r.Level_of_System__c,
                            Account__r.Id,
                            Account__r.Name,
                            Account__r.Client_Former_Name__c,
                            Account__r.Type,
                            Account__r.Industry,
                            Account__r.Industry__c,
                            Account__r.NAICS_Industry__c,
                            Account__r.NAICSCode__c,
                            Account__r.Customer_Success_Segment__c,
                            Super_Product_Family__c,
                            Product_Family__c,
                            Name,
                            Level_of_Subscription__c,
                            Asset_Status__c,
                            Annual_Recurring_Revenue__c,
                            CurrencyIsoCode
                          FROM Asset__c
                          WHERE Account__r.Test_Account__c = FALSE
                          AND Annual_Recurring_Revenue__c > 0
                          AND Platform_Configuration__r.Active__c = TRUE
                          AND Platform_Configuration__r.Id != NULL")

# Cleanup and Flags
Accounts <- Accounts_all %>%
         # flag Healthcare accounts
  mutate(Healthcare = grepl("Health|Hospital|Medical",
                            coalesce(Account__r.Industry,
                                     Account__r.Industry__c,
                                     Account__r.NAICS_Industry__c)),
         # set null 'On Platform' values to No
         Platform_Configuration__r.Gateway__c = Platform_Configuration__r.Gateway__c %>% coalesce("No"),
         # replace NA platform keys with blanks
         Platform_Configuration__r.Platform_Key__c = Platform_Configuration__r.Platform_Key__c %>% replace_na(""),
         # identify Standard EP Customers
         Product = case_when(Platform_Configuration__r.Name=='EthicsPoint' &
                               Platform_Configuration__r.Platform_Key__c=='XSTANDARD' ~ 'EthicsPoint Standard',
                             TRUE ~ Platform_Configuration__r.Name))

# Mapping and Transformations ----
Accounts_for_output <- Accounts %>%
         # Remove Assets not On Maintenance or Pre-Maintenance Status, Customer Hosted NE
  filter(#Asset_Status__c %in% c("On Maintenance", "Pre-Maintenance") &
           Platform_Configuration__r.Hosting_Method_NE__c %>% coalesce('') != 'Customer Hosted') %>%
         # Customers on NAVEX One - 'On Platform' = 'Yes'
  mutate(`On NAVEX One` = Platform_Configuration__r.Gateway__c=="Yes",
         # Customers Ready for Platform - Not EP Standard and Platform Migration Status is 'Not on Platform', 'Ready For Platform' or EP (not Standard) not on Platform
         `Ready for NAVEX One` = (Product != 'EthicsPoint Standard' &
                                    Platform_Configuration__r.Platform_Migration_Status__c %in% c('Not on Platform', 'Ready For Platform')) |
           (Product=='EthicsPoint' &
              Platform_Configuration__r.Gateway__c=='No'),
         # Blockers - PT Customers in Healthcare Industry and Platform Migration Status is 'Ready For Platform'
         `Blockers` = Product=="Policy Management" & Healthcare==TRUE & Platform_Configuration__r.Platform_Migration_Status__c=='Ready For Platform',
         # Constraints - NE Customers with Incompatible or non-Standard languages
         `Constraints` = Platform_Configuration__r.Incompatible_Courses_NE__c==TRUE | Platform_Configuration__r.Languages_Non_English_NE__c==TRUE,
         # Ready for NAVEX One after Blockers - EP Standard Customers or Platform Migration Status is 'Ready For Platform'
         `Ready for NAVEX One after Blockers` = Product=='EthicsPoint Standard' | Platform_Configuration__r.Platform_Migration_Status__c=='Not Ready for Platform',
         # CSM Accounts Ready for NAVEX One - `Ready for NAVEX One` is TRUE and Account has CSM (Not Low-Touch)
         `CSM Accounts Ready for NAVEX One` = `Ready for NAVEX One` & !grepl("Low|Tech|^$", `Account__r.Customer_Success_Segment__c` %>% coalesce("")),
         # Change boolean to numeric values
         across(c(`On NAVEX One`,
                  `Ready for NAVEX One`,
                  `Blockers`,
                  `Constraints`,
                  `Ready for NAVEX One after Blockers`,
                  `CSM Accounts Ready for NAVEX One`), as.numeric),
         # Change boolean values to Account Id to allow for summary at account level
         across(c(`On NAVEX One`,
                  `Ready for NAVEX One`,
                  `Blockers`,
                  `Constraints`,
                  `Ready for NAVEX One after Blockers`,
                  `CSM Accounts Ready for NAVEX One`), ~ if_else(.x==1, Account__r.Id, "") %>% na_if(""), .names = "{.col}_Acct_Id"),
         # Flag for GRC Insights breakout
         `GRC Insights` = Product=='EthicsPoint' & grepl('Enterprise', Platform_Configuration__r.Level_of_System__c %>% coalesce("")),
         # Replace NA values for GRC Insights breakout
         Platform_Configuration__r.Insights__c = Platform_Configuration__r.Insights__c %>% coalesce(FALSE),
         .keep="used")

# GRC Insights subset
Accounts_for_output_subset <- Accounts_for_output %>%
         # Subset for EP Customers with Insights
  filter(`GRC Insights`==TRUE) %>%
  mutate(Product = "GRC Insights",
         `On NAVEX One` = Platform_Configuration__r.Insights__c,
         `Ready for NAVEX One` = !Platform_Configuration__r.Insights__c,
         # Change booleans to numeric values
         across(c(`On NAVEX One`, `Ready for NAVEX One`), as.numeric),
         # Change boolean values to Account Id to allow for summary at account level
         across(c(`On NAVEX One`,`Ready for NAVEX One`), ~ if_else(.x==1, Account__r.Id, "") %>% na_if(""), .names = "{.col}_Acct_Id"))

# Bind Subset
Accounts_for_output <- bind_rows(Accounts_for_output,
                                 Accounts_for_output_subset) %>% distinct()
# Summaries ----
# Summarize output
Summary <- Accounts_for_output %>%
  group_by(Product) %>%
  summarize(across(c(`On NAVEX One`,
                     `Ready for NAVEX One`,
                     `Blockers`,
                     `Constraints`,
                     `Ready for NAVEX One after Blockers`,
                     `CSM Accounts Ready for NAVEX One`,
                     ), sum, na.rm=TRUE),
            across(ends_with("_Acct_Id"), ~ n_distinct(.x, na.rm = TRUE)),
            # Change Names to match Summary row names
            Product = case_when(Product=="Lockpath" ~ "NAVEX IRM*",
                                Product=="Compliance Training" ~ "NAVEX Engage (NAVEX Hosted)",
                                Product=="Policy Management" ~ "PolicyTech",
                                Product=="WhistleB" ~ "WhistleB*",
                                TRUE ~ Product %>% coalesce("")),
            .groups = "drop") %>%
  # remove untracked products
  filter(!Product %in% c("AlertLine/IntegriLink", "GRC Suite","")) %>%
  # sort products by readiness
  arrange(`Ready for NAVEX One after Blockers`)

if (config$method == "by db") {
  # Current method uses count of databases ----
  # Summarize output by count of databases
  Summary_by_db <- Summary %>%
     # remove columns for summary at account level
     distinct(across(-c(ends_with("_Acct_Id"))))

   # Print results to console
   knitr::kable(Summary_by_db, format = "markdown")
   } else if (config$method == "by account") {
     # Alternative method using count of Accounts instead of count of databases ----
     # Summarize output by count of Accounts
     Summary_by_account <- Summary %>%
       # remove columns for summary at account level for now
       distinct(across(c(Product, ends_with("_Acct_Id")))) %>%
       rename_with(~str_remove(., '_Acct_Id'))

     # Print results to console
     knitr::kable(Summary_by_account, format = "markdown")
}



# Output ----
# Save output to Workbook in SharePoint
wb <- loadWorkbook(paste0(config$sharepoint, "\\", config$wb))
cat("Loaded", paste0(config$sharepoint, "\\", config$wb))
summary_ws <- paste0(lubridate::today(),"-Summary")
if (!summary_ws %in% sheets(wb)) {
  cat("Adding", summary_ws, "to", config$wb)
  addWorksheet(wb,summary_ws)
}

cat("Writing Summary", config$method, "to", summary_ws, "and Summary tab of", config$wb)
writeData(wb,summary_ws,Summary_by_db)
writeData(wb,sheet = "Source", Summary_by_db, colNames = TRUE)
cat("Saving changes to", config$wb)
saveWorkbook(wb,paste0(config$sharepoint, "\\", config$wb),overwrite = TRUE)

cat("Summary added to", paste0(config$sharepoint, "\\", config$wb), "\nScreenshot Output tab for Board Deck slide")
